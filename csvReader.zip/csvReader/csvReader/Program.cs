﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csvReader
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //chama a função que processa o arquivo csv;
            readCSVFile();
            //pausa o console para que possa ser lido o conteúdo na tela;
            Console.ReadLine();
        }
        static void readCSVFile()
        {
            //armazena cada linha do arquivo no Array csvRows;
            //O arquivo produtcs.csv precisa estar na pasta csvReader\csvReader\bin\Debug;
            //foi colocado neste diretorio para não precisar ficar definindo um diretorio diferente no "ReadAllLines" toda vez;
            string[] csvRows = File.ReadAllLines("products.csv");

            //cria uma variavel lista "productList" do tipo "Product";
            List<Product> productList = new List<Product>();

            //para cada indexo ([0], [1], [2]), essa função é executada;
            //meio mais limpo de fazer for(int i=0;i<productList.Count;i++){}
            foreach (var line in csvRows)
            {
                //Cada linha do product.csv tem 4 colunas; cada coluna é separado por um ","; o array "lineValues" sepeara cada coluna por ","
                //e joga cada valor da linha em um indexo (valor da coluna 1 vai no lineValues[0], valor da coluna 2 vai no lineValues[1], etc.
                string[] lineValues = line.Split(',');

                //variavel "productObj" instancia a classe Product e cria um novo objeto "Product"; ele define cada variavel da classe de acordo
                //com o valor do respectivo indexo da variavel "lineValues"
                //(o indexo [0] do "lineValues" tem o valor do nome, então Name = lineValues[0],o indexo [1] do "lineValues" tem o valor do preço, então Price = lineValues[1], etc.
                Product productObj = new Product() { Name = lineValues[0], Price = lineValues[1], Brand = lineValues[2], Weight = lineValues[3] };

                //adiciona o "productObj" na lista "productList"
                productList.Add(productObj);
            }
            Console.WriteLine("PRODUCTS");

            //para cada indexo [] da lista "productList" (representado por "product"), o "ForEach" vai pegar os valores do objeto "Produto" contido no respectivo indexo
            //e escrever no console; jeito mais limpo do que Console.WriteLine(product.Name.toString()+","+product.Price.toString()+","+product.Brand.toString()+","+product.Weight.toString()));
            productList.ForEach(product => Console.WriteLine($"{product.Name} {product.Price} {product.Brand} {product.Weight}"));

        }
    }
}
