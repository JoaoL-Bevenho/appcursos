﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csvReader
{
    public class Product
    {
        //declaração de variaveis
        private string name;
        private string price;
        private string brand;
        private string weight;

        //decalaração dos Getters (pegar valor) e Setters (definir valor) de cada Variavel; sintaxe mais limpo do que o antigo
        //public string Name { get { return name; } set { name = value; } }
        public string Name { get => name; set => name = value; }
        public string Price { get => price; set => price = value; }
        public string Brand { get => brand; set => brand = value; }
        public string Weight { get => weight; set => weight = value; }

        //definido uma função que permite o instanciamento de um objeto da classe;
        //product = new Product() { Name = "Ketchup", Price = "2.50", Brand = "Heinz", Weight = "500ml" };
        public Product()
        {
            this.name = Name;
            this.price = Price;
            this.brand = Brand;
            this.weight = Weight;
        }
    }
}
