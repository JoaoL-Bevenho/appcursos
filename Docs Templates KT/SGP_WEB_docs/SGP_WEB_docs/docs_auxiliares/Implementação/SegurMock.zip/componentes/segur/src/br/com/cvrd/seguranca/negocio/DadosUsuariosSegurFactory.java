package br.com.cvrd.seguranca.negocio;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class DadosUsuariosSegurFactory {

    private static final String NIVEL = "nivel";

    private static final String PREFIXO_PARAMETRO_DEFAULT = "param.default.";

	private static final String USUARIOS = "Usuarios";

    private static final String CHAVES = "chaves";

    private static final String EMPRESA = "empresa";

    private static final String MATRICULA = "matricula";

    private static final String NOME = "nome";
    
    private Map gruposUsuario = new HashMap();

    private Map usuarios = new HashMap();

    private Map autorizacoes = new HashMap();
    
    /**
     * Map onde a KEY � o nome do usu�rio, e onde cada elemento � outro MAP, cuja KEY s�o as transa��es com parametros associados.
     * Os elementos associados �s transacoes s�o uma List de autoriza��es quase id�nticas, onde a �nica altera��o est� no valor do
     * par�metro (atributo valorParametro da classe Autorizacao)
     * */
    private Map autorizacoesParametros = new HashMap();

    private DadosUsuariosSegurFactory(String sistema) {

        ResourceBundle rbUsuarios = ResourceBundle.getBundle(sistema + "."
                + USUARIOS);
        String propriedadeChaves = rbUsuarios.getString(CHAVES);

        String[] chaves = propriedadeChaves.split(",");
        aplicaTrimNasChaves(chaves);
        int i = 0;
        String bundlePermissoesUsuario = null;
        try {
            for (; i < chaves.length; i++) {
                bundlePermissoesUsuario = sistema + "." + chaves[i];
                ResourceBundle rbUsuario = ResourceBundle
                        .getBundle(bundlePermissoesUsuario);
                String idUsuario = chaves[i].trim();
                String nome = obtemMensagemDoBundle(rbUsuario, NOME);
                String matricula = obtemMensagemDoBundle(rbUsuario, MATRICULA);
                String empresa = obtemMensagemDoBundle(rbUsuario, EMPRESA);               
                String nivel = obtemMensagemDoBundle(rbUsuario, NIVEL);
                

                Usuario u = new Usuario();
                u.setDadosUsuario(idUsuario, empresa, matricula, idUsuario, idUsuario, nivel, nome);                
                usuarios.put(chaves[i], u);

                recuperaTransacoes(rbUsuario, chaves[i]);
                preencheParametrosDefault(u, rbUsuario);
                
            }
        } catch (java.util.MissingResourceException e) {
            throw new RuntimeException(
                    "N�o foi possivel localizar o arquivo de propriedades do usu�rio "
                            + bundlePermissoesUsuario
                            + ", embora este esteja listado no arquivo Usuarios.properties.");
        }

    }

	private void preencheParametrosDefault(Usuario usuario,  ResourceBundle rbUsuario) {
    	
    	Enumeration ePropriedades = rbUsuario.getKeys();
    	
    	while (ePropriedades.hasMoreElements()) {
    		String propriedade = (String) ePropriedades.nextElement();
			
    		if (propriedade.startsWith(PREFIXO_PARAMETRO_DEFAULT)){
    			String chave = propriedade.substring(PREFIXO_PARAMETRO_DEFAULT.length());
    			if(chave.equals("grupo")){
        			gruposUsuario.put(usuario.getEmpresa().concat(usuario.getMatricula()), rbUsuario.getString(propriedade));
    			} else {
    				usuario.adicionaParametroDefault(new Parametro(chave, rbUsuario.getString(propriedade)));
    			}
                continue;
           }
		}    	
    }
    
    private String obtemMensagemDoBundle(ResourceBundle rbUsuario, String key) {
        String msg;
        try {
            msg = rbUsuario.getString(key);
        } catch (java.util.MissingResourceException e) {
            msg = "???" + key + "???";
        }
        return msg;
    }

    private void aplicaTrimNasChaves(String[] chaves) {
        for (int i = 0; i < chaves.length; i++) {
            chaves[i] = chaves[i].trim();
        }
    }

    private void recuperaTransacoes(ResourceBundle rbUsuario,
            String chaveUsuario) {

        Enumeration ePropriedades = rbUsuario.getKeys();
        ArrayList autorizacoesUsuario = new ArrayList();
        Map mapAutorizacoeUsuario = new HashMap();

        /**
         * MAP onde as KEYS s�o compostas pelas transa��es com parametros associados ao usu�rio, e os elementos s�o uma lista de
         * autoriza��es (classe Autorizacao) quase iguais (a unica altera��o encontra-se no atributo valorParametro da classe
         * Autorizacao). O Segur CVRD trabalha assim, com essa informa��o desnormalizada, e replicamos esse comportamento aqui.
         * */
        Map autorizacoesUsuarioParametros = new HashMap();

        while (ePropriedades.hasMoreElements()) {
            String propriedade = (String) ePropriedades.nextElement();
            if (NOME.equalsIgnoreCase(propriedade))
                continue;
            if (EMPRESA.equalsIgnoreCase(propriedade))
                continue;
            if (MATRICULA.equalsIgnoreCase(propriedade))
                continue;
            if (NIVEL.equalsIgnoreCase(propriedade))
                continue;
            if ( propriedade.startsWith(PREFIXO_PARAMETRO_DEFAULT)){
            	continue;
            }
            
            if ( propriedade.startsWith("parametros.")){
                incluiAutorizacaoParametro(chaveUsuario, propriedade,autorizacoesUsuarioParametros, rbUsuario, mapAutorizacoeUsuario );
                continue;
            }
            
            Autorizacao a = new Autorizacao();
            if (mapAutorizacoeUsuario.containsKey(propriedade)) {
                a = (Autorizacao) mapAutorizacoeUsuario.get(propriedade);
            }
            a.setTransacao(propriedade);
            String[] acessos = rbUsuario.getString(propriedade).split(",");

            for (int i = 0; i < acessos.length; i++) {
                String acesso = acessos[i];
                if ("L".equals(acesso))
                    a.setLeitura(true);
                else if ("I".equals(acesso))
                    a.setInclusao(true);
                else if ("A".equals(acesso))
                    a.setAlteracao(true);
                else if ("E".equals(acesso))
                    a.setExclusao(true);
                else
                    throw new RuntimeException(
                            "Foi definido um acesso desconhecido para a transa��o " + a.getTransacao() + " do usu�rio "
                                    + chaveUsuario + "... op��es v�lidas: L, A, I ou E.");
            }

            if (!mapAutorizacoeUsuario.containsKey(propriedade)) {
                autorizacoesUsuario.add(a);
                mapAutorizacoeUsuario.put(propriedade, a);
            }
        }
        autorizacoes.put(chaveUsuario, autorizacoesUsuario);
        autorizacoesParametros.put(chaveUsuario, autorizacoesUsuarioParametros);
    }

    private void incluiAutorizacaoParametro(String chaveUsuario, String propriedade, Map autorizacoesUsuarioParametros, ResourceBundle rbUsuario, Map mapAutorizacoeUsuario) {
        String transacao = propriedade.substring(11);
        Autorizacao a = new Autorizacao();
        if (mapAutorizacoeUsuario.containsKey(transacao)) {
            a = (Autorizacao) mapAutorizacoeUsuario.get(transacao);
        }
        String[] parametrosDaTransacao = rbUsuario.getString(propriedade).split(",");
        List listaAutorizacoesComParametrosDaTransacao = new ArrayList();
        for (int i = 0; i < parametrosDaTransacao.length; i++) {
            Autorizacao autorizacao = new Autorizacao();
            autorizacao.setTransacao(transacao);
            autorizacao.setAlteracao(a.isAlteracao());
            autorizacao.setExclusao(a.isExclusao());
            autorizacao.setInclusao(a.isInclusao());
            autorizacao.setLeitura(a.isLeitura());
            autorizacao.setValorParametro(parametrosDaTransacao[i]);
            listaAutorizacoesComParametrosDaTransacao.add(autorizacao);
        }
        
        autorizacoesUsuarioParametros.put(transacao, listaAutorizacoesComParametrosDaTransacao);
    }

    public List obtemAutorizacoesUsuario(String chaveUsuario) {
        return (List) autorizacoes.get(chaveUsuario);
    }
    
    public Map obtemAutorizacoesParametrosUsuario(String chaveUsuario) {
        return (Map) autorizacoesParametros.get(chaveUsuario);
    }

    public Usuario obtemUsuario(String chaveUsuario) {
        return (Usuario) usuarios.get(chaveUsuario);
    }

    public Map obtemUsuarios() {
        return usuarios;
    }
    
    public Map obtemGruposUsuarios() {
        return gruposUsuario;
    }
    
    public static DadosUsuariosSegurFactory getInstance(String sistema) {
        return new DadosUsuariosSegurFactory(sistema);
    }
}