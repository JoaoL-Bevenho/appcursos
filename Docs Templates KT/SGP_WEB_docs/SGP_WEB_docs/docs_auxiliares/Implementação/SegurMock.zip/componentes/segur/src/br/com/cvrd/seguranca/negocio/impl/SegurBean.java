package br.com.cvrd.seguranca.negocio.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.Handle;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import br.com.cvrd.seguranca.negocio.Autorizacao;
import br.com.cvrd.seguranca.negocio.DadosUsuariosSegurFactory;
import br.com.cvrd.seguranca.negocio.ExcecaoAcessoBD;
import br.com.cvrd.seguranca.negocio.ExcecaoAcessoDiretorio;
import br.com.cvrd.seguranca.negocio.ExcecaoSegur;
import br.com.cvrd.seguranca.negocio.ExcecaoTransacaoSemParametro;
import br.com.cvrd.seguranca.negocio.ExcecaoUsuarioNaoCadastrado;
import br.com.cvrd.seguranca.negocio.ExcecaoUsuarioSenhaInvalidos;
import br.com.cvrd.seguranca.negocio.Grupo;
import br.com.cvrd.seguranca.negocio.Segur;
import br.com.cvrd.seguranca.negocio.Usuario;

/**
 * @author Carlos Eduardo Vargas Miranda (cevmiranda@yahoo.com.br)
 */
public class SegurBean implements SessionBean, Segur {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private static Map mapAutorizacoesParametrosPorUsuario = new HashMap();
    
    private static boolean mapaPopulado = false;

    public void ejbCreate() {
    }

    public void ejbActivate() {
    }

    public void ejbPassivate() {
    }

    public void ejbRemove() {
    }

    public void setSessionContext(SessionContext ctx) {

    }

    public Usuario obterDadosUsuario(String chaveUsuario, String sistema, String instancia) throws ExcecaoSegur,
            ExcecaoUsuarioNaoCadastrado {
        Usuario usuario = DadosUsuariosSegurFactory.getInstance(sistema).obtemUsuario(chaveUsuario);
        if (usuario == null)
            throw new ExcecaoUsuarioNaoCadastrado();
        return usuario;
    }

    public boolean autenticarUsuario(String codUsuario, String senha) throws ExcecaoSegur {
        if ("ABC".equals(codUsuario))
            throw new ExcecaoUsuarioNaoCadastrado();

        if ("DEF".equals(codUsuario))
            throw new ExcecaoAcessoBD("usuario " + codUsuario + " n�o autorizado");

        if ("senha".equals(senha))
            throw new ExcecaoUsuarioSenhaInvalidos();
        
        if ("acesso".equals(codUsuario)){
            throw new ExcecaoAcessoDiretorio();
        }

        return true;
    }

    public boolean autenticarUsuarioDiretorio(String codUsuario, String senha) throws ExcecaoSegur {
        return autenticarUsuario(codUsuario, senha);
    }

    public Collection obterAutorizacoesSistema(String chaveUsuario, String sistema, String instancia) throws ExcecaoSegur,
            ExcecaoUsuarioNaoCadastrado {
        DadosUsuariosSegurFactory factory = DadosUsuariosSegurFactory.getInstance(sistema);
        Collection auts = factory.obtemAutorizacoesUsuario(chaveUsuario);
        synchronized (mapAutorizacoesParametrosPorUsuario) {
            mapAutorizacoesParametrosPorUsuario.put(chaveUsuario, factory.obtemAutorizacoesParametrosUsuario(chaveUsuario));
            mapaPopulado = true;
        }
        return auts;
    }

    /**
     * @return Cole��o de autoriza��es (Classe Autorizacao), todas relativas � uma mesma transa��o, onde somente o que varia � o
     * atributo valorParametro.
     * 
     * Da maneira que est� implementado, � necess�rio chamar antes, em algum momento, o m�todo
     * obterAutorizacoesSistema (String chaveUsuario, String sistema, String instancia), pois ele � respons�vel por carregar as
     * informa��es do arquivo de propriedades do usu�rio, al�m de carregar o mapAutorizacoesParametrosPorUsuario
     * 
     * OBS: Nessa implementa��o atual do mock n�o funcionar� para usu�rios que tenham o mesmo nome e estejam cadastrados em
     * dois sistemas diferentes!!!!!
     * @throws ExcecaoSegur 
     * 
     * @see obterAutorizacoesSistema(String chaveUsuario, String sistema, String instancia)
     * 
     */
    public Collection obterParametros(String usuario, String transacao, String instanciaBD) throws ExcecaoSegur {
        if (!mapaPopulado) {
            throw new RuntimeException(
                    "Erro na utiliza��o do MOCK!!! antes de chamar o m�todo obterParametros(...), " +
                    "chame o m�todo obterAutorizacoesSistema(...)");
        }
        
        if (!mapAutorizacoesParametrosPorUsuario.containsKey(usuario)) {
            return null;
        }
        
        Map mapAutorizacoesParametroDoUsuario = (Map) mapAutorizacoesParametrosPorUsuario.get(usuario);
        if (!mapAutorizacoesParametroDoUsuario.containsKey(transacao)) {
            return null;
        }
        
        List listaAutorizacoesParametro = (List) mapAutorizacoesParametroDoUsuario.get(transacao);
        if (null==listaAutorizacoesParametro || listaAutorizacoesParametro.isEmpty()) {
            throw new ExcecaoTransacaoSemParametro();
        }
        return listaAutorizacoesParametro;
    }

    /*
     * m�todos n�o implementados nesse mock
     */
    public Autorizacao obterDadosSeguranca(String s, String s1, String s2) throws ExcecaoSegur {
        return null;
    }

    public Autorizacao obterDadosSeguranca(String s, String s1, String s2, String s3) throws ExcecaoSegur {
        return null;
    }

    public Collection obterAutorizacoesGrupo(String s, String s1, String s2) throws ExcecaoSegur {
        return null;
    }

    public boolean validaUsuarioGrupo(String codUsuario, String grupo) throws ExcecaoSegur {
        if(codUsuario.equals("1")){
            if(grupo.equals("ADM")) {
            	return true;
            }
            return false;
        } else if(codUsuario.equalsIgnoreCase("c0101956")){
            if(grupo.equals("HELP_DESK")) {
            	return true;
            }
            return false;
        } else if(codUsuario.equalsIgnoreCase("c0101958")) {
            if(grupo.equals("GESTOR_ATENDIMENTO")) {
            	return true;
            }
            return false;
        }
        return true;
    }

    public Collection retornaValorAtributosUsuario(String s, String as[]) throws ExcecaoSegur {
        return null;
    }

    public boolean excluiUsuarioGrupo(String s, String s1) throws RemoteException, ExcecaoSegur {
        return false;
    }

    public Collection obterUsuarioInstanciaExclusao_eDir() throws RemoteException, ExcecaoSegur {
        return null;
    }
    
    public Collection consultaUsuariosSistema(String sistema, String instanciaBD) throws RemoteException, ExcecaoSegur {
        Map usuariosMap = DadosUsuariosSegurFactory.getInstance(sistema).obtemUsuarios();

        Collection usuarios = new ArrayList();
        
        for (Iterator iterator = usuariosMap.entrySet().iterator(); iterator.hasNext();) {
            Map.Entry type = (Map.Entry) iterator.next();
            Usuario usuario = (Usuario) type.getValue();
            usuarios.add(usuario);
        }
        return usuarios;
    }

    public Collection consultaGruposSistema(String arg0, String arg1) throws ExcecaoSegur, RemoteException {
        // TODO Auto-generated method stub
        return null;
    }

    public Collection consultaUsuariosGrupoSistema(String arg0, String arg1, String arg2) throws ExcecaoSegur, RemoteException {
        // TODO Auto-generated method stub
        return null;
    }

    public EJBHome getEJBHome() throws RemoteException {
        // TODO Auto-generated method stub
        return null;
    }

    public Handle getHandle() throws RemoteException {
        // TODO Auto-generated method stub
        return null;
    }

    public Object getPrimaryKey() throws RemoteException {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isIdentical(EJBObject arg0) throws RemoteException {
        // TODO Auto-generated method stub
        return false;
    }

    public void remove() throws RemoteException, RemoveException {
        // TODO Auto-generated method stub
        
    }

    public Collection consultaGruposUsuario(String codUsuario, String sistema, String instanciaBD) throws ExcecaoSegur, RemoteException {
        List grupos = new ArrayList();
        
        DadosUsuariosSegurFactory factory = DadosUsuariosSegurFactory.getInstance(sistema);

        Map gruposUsuario = factory.obtemGruposUsuarios();
        
    	Grupo grupo = new Grupo();
        
        grupo.setDadosGrupo((String)gruposUsuario.get(codUsuario), (String)gruposUsuario.get(codUsuario));
        grupos.add(grupo);
        return grupos;
    }
}
