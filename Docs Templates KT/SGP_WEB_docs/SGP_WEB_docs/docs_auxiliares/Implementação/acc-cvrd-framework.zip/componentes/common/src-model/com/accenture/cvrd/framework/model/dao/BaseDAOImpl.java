package com.accenture.cvrd.framework.model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe base para as implementa��es de DAO.
 * 
 * @author ricardo.goes
 * 
 */
public class BaseDAOImpl {

	Log logger = LogFactory.getLog(BaseDAOImpl.class);

	/**
	 * Libera os recursos JDBC e de banco de dados associados ao objeto
	 * <code>Statement</code>.
	 * 
	 * @param ps Statement a ser liberado
	 */
	protected void release(PreparedStatement ps) {
		if (ps != null) {
			try {
				ps.close();
			} catch (SQLException e) {
				logger.error(e);
			}
		}
	}

	/**
	 * Libera os recursos JDBC e de banco de dados associados ao objeto
	 * <code>ResultSet</code>.
	 * 
	 * @param rs ResultSet a ser liberado
	 */
	protected void release(ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				logger.error(e);
			}
		}
	}
}
