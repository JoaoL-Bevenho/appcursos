package com.accenture.cvrd.framework.exception;

import com.accenture.cvrd.framework.util.notification.Notification;

/**
 * Classe base para exce��es checadas, previstas pela aplica��o.
 * 
 * @author ricardo.goes
 * 
 */
public class ApplicationException extends br.com.cvrd.framework.exception.ApplicationException {

	private static final long serialVersionUID = 1L;

	private Notification errors;

	/**
	 * Construtor
	 * 
	 * @param erros
	 *            Notifica��o com os erros que levaram ao lan�amento da exce��o
	 */
	public ApplicationException(Notification erros) {
		super();
		this.errors = erros;
	}

	/**
	 * Obt�m a notifica��o com os erros que levaram ao lan�amento da exce��o
	 * 
	 * @return notifica��o com os erros que levaram ao lan�amento da exce��o
	 */
	public Notification getNotification() {
		if (this.errors == null) {
			this.errors = new Notification();
		}
		return this.errors;
	}

	/**
	 * Construtor
	 * 
	 * @param cause
	 *            Causa da exce��o
	 */
	public ApplicationException(Throwable cause) {
		super(cause);
	}

	/**
	 * Construtor default
	 * 
	 */
	public ApplicationException() {
		super();
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 * @param cause
	 *            Causa da exce��o
	 */
	public ApplicationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 */
	public ApplicationException(String message) {
		super(message);
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 * @param className
	 *            nome da classe onde a exce��o foi lan�ada
	 * @param method
	 *            nome do m�todo onde a exce��o foi lan�ada
	 * @param params
	 *            par�metros recebidos pelo m�todo onde a exce��o foi lan�ada
	 */
	public ApplicationException(String message, String className, String method, String[][] params) {
		super(message);
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 * @param e
	 *            Exce��o que originou a exce��o de aplica��o
	 * @param className
	 *            nome da classe onde a exce��o foi lan�ada
	 * @param method
	 *            nome do m�todo onde a exce��o foi lan�ada
	 * @param params
	 *            par�metros recebidos pelo m�todo onde a exce��o foi lan�ada
	 */
	public ApplicationException(String message, Throwable e, String className, String method, String[][] params) {
		super(message, e);
	}
}
