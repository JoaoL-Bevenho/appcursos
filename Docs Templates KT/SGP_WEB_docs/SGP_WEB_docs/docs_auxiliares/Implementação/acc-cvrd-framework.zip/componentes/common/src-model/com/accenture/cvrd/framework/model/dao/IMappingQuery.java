package com.accenture.cvrd.framework.model.dao;

import java.sql.Connection;
import java.util.List;

import com.accenture.cvrd.framework.util.DataFilter;
import com.accenture.cvrd.framework.util.DataPagination;

/**
 * Interface para uma query que utiliza mapeamento com objetos de uma base de
 * dados.
 * 
 * Define as opera��es CRUD b�sicas que podem ser executadas por uma query
 * mapeada, e algumas possibilidades de consultas por filtro.
 * 
 * Exp�e m�todos para obten��o da sintaxe de queries CRUD.
 * 
 * @author ricardo.goes
 * @see DataFilter
 * 
 */
public interface IMappingQuery {

	/**
	 * Apaga o objeto representado pelo objeto de transfer�ncia <code>to</code>
	 * da base de dados, de acordo com o mapeamento configurado.
	 * 
	 * @param to
	 *            Objeto de transfer�ncia a ser exclu�do da base de dados
	 * @param status
	 *            conex�o com a base
	 */
	void deleteByKey(Object to, Connection status);

	/**
	 * Apaga o objeto representado pela chave <code>key</code> da base de
	 * dados, de acordo com o mapeamento configurado.
	 * 
	 * @param key
	 *            Chave de identifica��o do objeto a ser exclu�do da base de
	 *            dados
	 * @param status
	 *            conex�o com a base
	 */
	void deleteByKey(long key, Connection status);

	/**
	 * Executa a query reutiliz�vel.
	 */
	void execute();

	/**
     * <p>
     * Executa a query reutiliz�vel com lista de par�metros. A ordem dos
     * par�metros na lista <code>parms</code> deve ser a mesma em que os
     * mesmos s�o referenciados na query.
     * </p>
     * <p>
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * </p>
     * 
     * @param parametros
     */
	void execute(Object[] parametros);

    /**
     * <p>
     * Executa a query com lista de par�metros e respectivos tipos. A ordem dos
     * par�metros na lista <code>parms</code> deve ser a mesma em que os
     * mesmos s�o referenciados na query.
     * </p>
     * 
     * <p>
     * Os tipos informados para os par�metros em <code>types</code> s�o
     * definidos em java.sql.Types.
     * </p>
     * 
     * @param parametros
     *            Parametros passados para a query, na ordem em que s�o
     *            referenciados
     * @param types
     *            tipos dos par�metros
     */
	void execute(Object[] parametros, int[] types);

	/**
	 * Executa a query <code>sql</code> com lista de par�metros e respectivos
	 * tipos. A ordem dos par�metros na lista <code>parms</code> deve ser a
	 * mesma em que os mesmos s�o referenciados na query.
	 * 
	 * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
	 * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
	 * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
	 * levantada.
	 * 
	 * @param sql
	 * @param parametros
	 *            Parametros passados para a query, na ordem em que s�o
	 *            referenciados
	 * @param status
	 *            Conex�o com o banco
	 */
	void execute(String sql, Object[] parametros, Connection status);

    /**
     * Executa a query <code>sql</code> com lista de par�metros e respectivos
     * tipos. A ordem dos par�metros na lista <code>parms</code> deve ser a
     * mesma em que os mesmos s�o referenciados na query.
     * 
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * 
     * @param sql
     *            query a ser executada
     * @param parametros
     *            Parametros passados para a query, na ordem em que s�o
     *            referenciados
     * @param types
     *            tipos dos par�metros
     * @param con
     *            conex�o com o banco de dados
     */
    public void execute(String sql, Object[] parametros, int[] types, Connection con);

	/**
	 * Executa a query. Os dados s�o retornados numa lista. Cada item da lista �
	 * populado pelo m�todo <code>mapRows</code>.
	 * 
	 * @return Lista com os dados obtidos na execu��o da query
	 */
	List executeQuery();

	/**
	 * Executa a query com lista de par�metros. A ordem dos par�metros na lista
	 * <code>parms</code> deve ser a mesma em que os mesmos s�o referenciados
	 * na query <code>sql</code>.
	 * 
	 * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
	 * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
	 * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
	 * levantada.
	 * 
	 * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
	 * m�todo <code>mapRows</code>.
	 * 
	 * @param parametros
	 *            Parametros passados para a query, na ordem em que s�o
	 *            referenciados
	 * @return Lista com os dados obtidos na execu��o da query
	 */
	List executeQuery(Object parametros[]);

	/**
	 * Executa a query com lista de par�metros e respectivos tipos. A ordem dos
	 * par�metros na lista <code>parms</code> deve ser a mesma em que os
	 * mesmos s�o referenciados na query informada no construtor.
	 * 
	 * Os tipos informados para os par�metros em <code>types</code> s�o
	 * definidos em {@link #java.sql.Types java.sql.Types}.
	 * 
	 * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
	 * m�todo <code>mapRows</code>.
	 * 
	 * @param parametros
	 *            Parametros passados para a query, na ordem em que s�o
	 *            referenciados
	 * @param types
	 *            tipos dos par�metros
	 * 
	 * @return resultado da consulta
	 */
	List executeQuery(Object parametros[], int types[]);

	/**
	 * Executa a query com lista de par�metros. A ordem dos par�metros na lista
	 * <code>parms</code> deve ser a mesma em que os mesmos s�o referenciados
	 * na query <code>sql</code>.
	 * 
	 * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
	 * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
	 * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
	 * levantada.
	 * 
	 * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
	 * m�todo <code>mapRow</code>.
	 * 
	 * @param sql
	 *            Query a ser executada
	 * @param parametros
	 *            Parametros passados para a query, na ordem em que s�o
	 *            referenciados
	 * @param status
	 *            Conex�o com o banco
	 * 
	 * @return Lista com os dados obtidos na execu��o da query
	 */
	List executeQuery(String sql, Object[] parametros, Connection status);

	/**
	 * Executa a query informada em <code>sql</code>.
	 * 
	 * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
	 * m�todo <code>mapRow</code>.
	 * 
	 * @param sql
	 *            Query a ser executada
	 * @param status
	 *            Conex�o com o banco
	 * 
	 * @return Lista com os dados obtidos na execu��o da query
	 */
	List executeQuery(String sql, Connection status);

	/**
	 * Consulta todas as ocorrencias da tabela mapeada
	 * 
	 * @param status
	 *            Conex�o com o banco
	 * 
	 * @return Lista com todas as ocorrencias da tabela mapeada
	 */
	List findAll(Connection status);

	/**
	 * Consulta todas as ocorrencias da tabela mapeada, respeitando a ordena��o
	 * informada em <code>orderByFields</code>.
	 * 
	 * @param orderByFields
	 *            campos para ordena��o. Podem vir com a dire��o de ordena��o
	 *            junto (ex: campo1 asc)
	 * @param status
	 *            Conex�o com o banco
	 * 
	 * @return Lista com todas as ocorrencias da tabela mapeada
	 */
	List findAll(String[] orderByFields, Connection status);

	/**
	 * Consulta todas as ocorrencias da tabela mapeada usando a pagina��o
	 * configurada em <code>pagination</code>.
	 * 
	 * @param status
	 *            Conex�o com o banco
	 * @param pagination
	 *            configura��o de pagina��o
	 * 
	 * @return Lista com todas as ocorrencias da tabela mapeada
	 */
	List findAll(Connection status, DataPagination pagination);

	/**
	 * Consulta todas as ocorrencias da tabela mapeada, respeitando a ordena��o
	 * informada em <code>orderByFields</code>.
	 * 
	 * � usada a pagina��o configurada em <code>pagination</code>.
	 * 
	 * @param orderByFields
	 *            campos para ordena��o. Podem vir com a dire��o de ordena��o
	 *            junto (ex: campo1 asc)
	 * @param status
	 *            Conex�o com o banco
	 * @param pagination
	 * 
	 * @return lista ordenada com todas as ocorrencias da tabela mapeada
	 *         seguindo ordena��o
	 */
	List findAll(String[] orderByFields, Connection status, DataPagination pagination);

    /**
     * <p>
     * Executa a query de consulta com lista de par�metros. A ordem dos
     * par�metros na lista <code>columnValues</code> deve ser a mesma em que
     * os mesmos s�o encontrados na lista com os nomes das colunas a serem
     * filtradas em <code>columnNames</code>.
     * </p>
     * 
     * <p>
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * </p>
     * 
     * <p>
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRow</code>.
     * </p>
     * 
     * @param columnNames
     * @param columnValues
     *            Parametros passados para a query, na ordem em que aparecem em
     *            <code>columnNames</code>
     * @param status
     *            conex�o com a base
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
	List findByColumns(String[] columnNames, Object[] columnValues, Connection status);

    /**
     * <p>
     * Executa a query de consulta com lista de par�metros. A ordem dos
     * par�metros na lista <code>columnValues</code> deve ser a mesma em que
     * os mesmos s�o encontrados na lista com os nomes das colunas a serem
     * filtradas em <code>columnNames</code>.
     * </p>
     * 
     * <p>
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * </p>
     * 
     * <p>
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRow</code>.
     * </p>
     * 
     * <p>
     * Um crit�rio de ordena��o pode ser usado. � baseado no array
     * <code>orderByFields</code>, que cont�m os campos usados na ordena��o,
     * por ordem de preced�ncia. Podem vir com a dire��o de ordena��o junto (ex:
     * <code>"campo1 asc"</code>)
     * </p>
     * 
     * @param columnNames
     * @param columnValues
     *            Parametros passados para a query, na ordem em que aparecem em
     *            <code>columnNames</code>
     * @param orderByFields
     *            campos usados na ordena��o, por ordem de preced�ncia. Podem
     *            vir com a dire��o de ordena��o junto (ex: campo1 asc)
     * @param status
     *            conex�o com a base
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
	List findByColumns(String[] columnNames, Object[] columnValues, String[] orderByFields, Connection status);

	/**
	 * <p>
	 * Encontra o objeto cuja chave est� representada pelo objeto de
	 * transfer�ncia <code>to</code> de acordo com o mapeamento configurado.
	 * </p>
	 * 
	 * @param to
	 *            Objeto de transfer�ncia a ser exclu�do da base de dados
	 * @param status
	 *            conex�o com a base
	 * @return
	 */
	Object findByKey(Object to, Connection status);

	/**
	 * Executa a query usando um <code>DataFilter</code>. As informa��es de
	 * filtros contidas em <code>filter</code> ser�o as mesmas utilizadas para
	 * gerar a sintaxe da query.
	 * 
	 * @param dataFilter
	 *            crit�rios de filtro (colunas e valores)
	 * @param status
	 *            conex�o com a base
	 * 
	 * @return
	 */
	public List findByFilter(DataFilter dataFilter, Connection status);

	/**
	 * Executa a query usando um <code>DataFilter</code>. As informa��es de
	 * filtros contidas em <code>filter</code> ser�o as mesmas utilizadas para
	 * gerar a sintaxe da query.
	 * 
	 * Os criterios de ordena��o em <code>orderByFields</code> s�o utilizados
	 * 
	 * @param df
	 * @param orderByFields
	 *            campos para ordena��o. Podem vir com a dire��o de ordena��o
	 *            junto (ex: campo1 asc)
	 * @param connection
	 * @return
	 */
	public List findByFilter(DataFilter df, String[] orderByFields, Connection connection);

	/**
	 * <p>
	 * Encontra o objeto identificado pela chave <code>key</code> de acordo
	 * com o mapeamento configurado.
	 * </p>
	 * 
	 * @param key
	 *            chave de identifica��o do objeto a ser encontrado na base
	 * @param status
	 *            conex�o com a base
	 * @return
	 */
	Object findByKey(long key, Connection status);

	/**
	 * <p>
	 * Obt�m o comando SQL de <code>DELETE</code> usando a chave como filtro,
	 * para o mapeamento fornecido pela query. � feito um cache para
	 * reutiliza��o do comando nas chamadas seguintes desse m�todo.
	 * </p>
	 * 
	 * @return string com o SQL de DELETE filtrado pela chave
	 */
	String getDeleteByKey();

	/**
	 * <p>
	 * Obt�m o comando SQL de <code>SELECT</code> sem filtro, para o
	 * mapeamento fornecido pela query. � feito um cache para reutiliza��o do
	 * comando nas chamadas seguintes desse m�todo.
	 * </p>
	 * 
	 * @return string com o SQL de SELECT
	 */
	String getFindAll();

	/**
	 * <p>
	 * Obt�m o comando SQL de <code>SELECT</code> usando a chave como filtro,
	 * para o mapeamento fornecido pela query. � feito um cache para
	 * reutiliza��o do comando nas chamadas seguintes desse m�todo.
	 * </p>
	 * 
	 * @return string com o SQL de SELECT filtrado pela chave
	 */
	String getFindByKey();

	/**
	 * @param dataFilter
	 * @param orderByFields
	 *            campos para ordena��o. Podem vir com a dire��o de ordena��o
	 *            junto (ex: campo1 asc)
	 * @return String com o SQL de SELECT montado ao utilizar o dataFilter
	 */
	String getFindByFilter(DataFilter dataFilter, String[] orderByFields);

	/**
	 * @param query
	 * @param parametros
	 * @param connection
	 * @return Quantidade de linhas retornadas pela query passada como argumento
	 */
	int executeCount(String query, Object[] parametros, Connection connection);

	/**
	 * <p>
	 * Obt�m o comando SQL de <code>INSERT</code> para o mapeamento fornecido
	 * pela query. � feito um cache para reutiliza��o do comando nas chamadas
	 * seguintes desse m�todo.
	 * </p>
	 * 
	 * @return string com o SQL de INSERT filtrado pela chave
	 */
	String getInsert();

	/**
	 * <p>
	 * Obt�m o comando SQL de <code>UPDATE</code> usando a chave como filtro,
	 * para o mapeamento fornecido pela query. � feito um cache para
	 * reutiliza��o do comando nas chamadas seguintes desse m�todo.
	 * </p>
	 * 
	 * @return string com o SQL de UPDATE
	 */
	String getUpdateByKey();

	/**
	 * Insere os dados do objeto de transfer�ncia <code>to</code> na base de
	 * dados, de acordo com o mapeamento configurado.
	 * 
	 * @param to
	 *            Objeto de transfer�ncia a ser inserido na base de dados
	 * @param status
	 *            conex�o com a base
	 */
	void insert(Object to, Connection status);

    /**
     * Insere os dados do objeto de transfer�ncia <code>to</code> na base de
     * dados, de acordo com o mapeamento configurado. Os atributos do objeto de
     * tranfer�ncia que utilizam sequence s�o atualizados ap�s a inser��o.
     * 
     * @param to
     *            Objeto de transfer�ncia a ser inserido na base de dados
     * @param types
     *            tipos dos par�metros
     * @param status
     *            conex�o com a base
     */
    public void insert(Object to, int[] types, Connection status);

	/**
	 * Libera recursos alocados pela inst�ncia.
	 * 
	 */
	void release();

	/**
	 * <p>
	 * Atualiza os dados do objeto de transfer�ncia <code>to</code> na base de
	 * dados, de acordo com o mapeamento configurado.
	 * </p>
	 * 
	 * @param to
	 *            Objeto de transfer�ncia a ser atualizado na base de dados
	 * @param status
	 *            conex�o com a base
	 */
	void updateByKey(Object to, Connection status);

	/**
	 * Retorna <code>true</code> caso o objeto representado por
	 * <code>to</code> exista na base.
	 * 
	 * @param to
	 *            objeto procurado na base
	 * @param status
	 *            conex�o com a base
	 * 
	 * @return <code>true</code> caso o objeto exista na base.
	 */
	boolean exists(Object to, Connection status);
}