package com.accenture.cvrd.framework.model.dao;

import com.accenture.cvrd.framework.util.EmptyArray;

/**
 * Crit�rio de compara��o por faixa de valores para ser aplicado em uma coluna.
 * A coluna satisfaz o crit�rio quando o seu conte�do estiver entre os valores
 * m�nimo e m�ximo do crit�rio (inclusive).
 * 
 * @author ricardo.goes
 * 
 */
public class ColumnRangeCriteria extends ColumnCriteria {

	private Object higher;

	private Object lower;

	/**
	 * Construtor
	 * 
	 * @param column
	 *            nome da coluna onde o crit�rio � aplicado
	 * @param lower
	 *            Valor m�nimo que a coluna deve possuir
	 * @param higher
	 *            Valor m�ximo que a coluna deve possuir
	 */
	public ColumnRangeCriteria(String column, Object lower, Object higher) {
		super(column);
		this.lower = lower;
		this.higher = higher;
	}

	/**
	 * getter para o valor m�nimo do crit�rio de range
	 * 
	 * @return
	 */
	public Object getLower() {
		return this.lower;
	}

	/**
	 * getter para o valor m�ximo do crit�rio de range
	 * 
	 * @return
	 */
	public Object getHigher() {
		return this.higher;
	}

	/**
	 * @see ColumnCriteria#getApplicableValues()
	 */
	public Object[] getApplicableValues() {
		if (isNull(lower) && isNull(higher)) {
			return EmptyArray.OBJECT;
		}

		if (!isNull(lower) && !isNull(higher)) {
			return new Object[] { lower, higher };
		}

		return (isNull(lower) ? new Object[] { higher } : new Object[] { lower });
	}

	/**
	 * @see ColumnCriteria#render(CriteriaRenderer)
	 */
	public String render(CriteriaRenderer criteriaRenderer) {
		return criteriaRenderer.renderCriteria(this);
	}
}
