package com.accenture.cvrd.framework.exception;

import com.accenture.cvrd.framework.util.notification.Notification;

/**
 * Classe base para exce��es n�o checadas, levantadas pela aplica��o.
 * 
 * @author ricardo.goes
 */
public class SystemException extends br.com.cvrd.framework.exception.SystemException {

	private static final long serialVersionUID = 1L;

	private Notification errors;

	/**
	 * Construtor
	 * 
	 * @param erros
	 *            Notifica��o com os erros que levaram ao lan�amento da exce��o
	 */
	public SystemException(Notification erros) {
		super();
		this.errors = erros;
	}

	/**
	 * Obt�m a notifica��o com os erros que levaram ao lan�amento da exce��o
	 * 
	 * @return notifica��o com os erros que levaram ao lan�amento da exce��o
	 */
	public Notification getNotification() {
		if (this.errors == null) {
			this.errors = new Notification();
		}
		return this.errors;
	}

	/**
	 * Construtor default
	 */
	public SystemException() {
		super();
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 * @param cause
	 *            Causa da exce��o
	 */
	public SystemException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 */
	public SystemException(String message) {
		super(message);
	}

	/**
	 * Construtor
	 * 
	 * @param cause
	 *            Causa da exce��o
	 */
	public SystemException(Throwable cause) {
		super(cause);
	}
}
