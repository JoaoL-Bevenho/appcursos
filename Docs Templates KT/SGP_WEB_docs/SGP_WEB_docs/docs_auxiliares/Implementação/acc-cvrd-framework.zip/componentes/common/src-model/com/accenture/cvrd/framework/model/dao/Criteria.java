package com.accenture.cvrd.framework.model.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.accenture.cvrd.framework.util.BaseDataFilter;
import com.accenture.cvrd.framework.util.DataFilter;
import com.accenture.cvrd.framework.util.DataPagination;

/**
 * Crit�rio de filtro de dados. Consiste numa lista de crit�rios espec�ficos,
 * que podem ter tipos variados.
 * 
 * Podem ser usados em queries, para filtrar resultados.
 * 
 * @author ricardo.goes
 * 
 * @see MappingQuery
 * @see QueryCriteria
 * @see BaseDataFilter
 */
public class Criteria {

	private List criteria = new ArrayList();

	/**
	 * construtor default
	 * 
	 */
	public Criteria() {
		super();
	}

	/**
	 * Adiciona ao crit�rio a compara��o de um atributo com uma lista de valores
	 * poss�veis para esse atributo.
	 * 
	 * @param attribute
	 *            nome do atributo
	 * @param values
	 *            lista de valores poss�veis
	 */
	public void in(String attribute, Iterator values) {
		this.criteria.add(new ColumnInCriteria(attribute, values));
	}

    /**
     * Adiciona ao crit�rio a compara��o de um atributo com uma lista de valores
     * poss�veis para esse atributo.
     * 
     * @param attribute
     *            nome do atributo
     * @param values
     *            lista de valores poss�veis
     */
    public void notIn(String attribute, Iterator values) {
        this.criteria.add(new ColumnNotInCriteria(attribute, values));
    }

	/**
	 * Adiciona ao crit�rio a compara��o de um atributo com o valor aceito para
	 * ele.
	 * 
	 * @param attribute
	 *            nome do atributo
	 * @param value
	 */
	public void equals(String attribute, Object value) {
		this.criteria.add(new ColumnEqualsCriteria(attribute, value));
	}
	
	/**
     * Adiciona ao crit�rio a compara��o de um atributo com o valor N�O aceito para
     * ele.
     * 
     * @param attribute
     *            nome do atributo
     * @param value
     */
    public void notEqual(String attribute, Object value) {
        this.criteria.add(new ColumnNotEqualsCriteria(attribute, value));
    }

	/**
	 * Adiciona ao crit�rio a compara��o de um atributo com os valores m�nimo e
	 * m�ximo aceitos para ele.
	 * 
	 * @param attribute
	 *            nome do atributo
	 * @param low
	 *            valor m�nimo aceito para o atributo
	 * @param high
	 *            valor m�ximo aceito para o atributo
	 */
	public void between(String attribute, Object low, Object high) {
		this.criteria.add(new ColumnRangeCriteria(attribute, low, high));
	}

	/**
	 * Adiciona ao crit�rio a compara��o de um atributo com uma m�scara a ser
	 * aplicada.
	 * 
	 * @param attribute
	 *            nome do atributo
	 * @param value
	 *            m�scara a ser aplicada na compara��o
	 */
	public void like(String attribute, String value) {
		this.criteria.add(new ColumnLikeCriteria(attribute, value));
	}

    /**
     * Adiciona ao crit�rio a compara��o de um atributo com uma m�scara a ser
     * aplicada, ignorando mai�sculas/min�sculas.
     * 
     * @param attribute
     *            nome do atributo
     * @param value
     *            m�scara a ser aplicada na compara��o
     */
    public void likeWithCaseIgnore(String attribute, String value) {
        this.criteria.add(new ColumnLikeWithCaseIgnoreCriteria(attribute, value));
    }

	/**
	 * Adiciona ao crit�rio a compara��o de um atributo com o valores m�nimo
	 * aceito para ele.
	 * 
	 * @param attribute
	 *            nome do atributo
	 * @param value
	 *            valor m�nimo aceito para o atributo
	 */
	public void greaterThan(String attribute, Object value) {
		this.criteria.add(new ColumnRangeCriteria(attribute, value, null));
	}

	/**
	 * Adiciona ao crit�rio a compara��o de um atributo com o valor m�ximo
	 * aceito para ele.
	 * 
	 * @param attribute
	 *            nome do atributo
	 * @param value
	 *            valor m�ximo aceito para o atributo
	 */
	public void lesserThan(String attribute, Object value) {
		this.criteria.add(new ColumnRangeCriteria(attribute, null, value));
	}

	/**
	 * Cria um objeto de filtro a partir do crit�rio
	 * 
	 * @param dataPagination
	 *            Objeto de pagina��o usado no filtro
	 * @return objeto de filtro
	 */
	public DataFilter toFilter(DataPagination dataPagination) {
		return new BaseDataFilter(this.toArray(), dataPagination);
	}

	/**
	 * Monta um array com as condi��es de filtro contidas no crit�rio.
	 * 
	 * @return array com as condi��es de filtro contidas no crit�rio
	 */
	public QueryCriteria[] toArray() {
		QueryCriteria[] queryCriterias = new QueryCriteria[this.criteria.size()];

		for (int i = 0; i < queryCriterias.length; i++) {
			queryCriterias[i] = (QueryCriteria) this.criteria.get(i);
		}

		return queryCriterias;
	}
}
