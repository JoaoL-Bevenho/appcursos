package com.accenture.cvrd.framework.model.dao;

/**
 * Operador booleano 'and' para ser usado em queries.
 * 
 * @author ricardo.goes
 * @see QueryCriteria
 */
public class AndBooleanOperator implements BooleanOperator {

	/**
	 * Construtor default
	 * 
	 */
	public AndBooleanOperator() {
		super();
	}

	/**
	 * Retorna a sintaxe SQL do operador
	 */
	public String toString() {
		return " and ";
	}
}
