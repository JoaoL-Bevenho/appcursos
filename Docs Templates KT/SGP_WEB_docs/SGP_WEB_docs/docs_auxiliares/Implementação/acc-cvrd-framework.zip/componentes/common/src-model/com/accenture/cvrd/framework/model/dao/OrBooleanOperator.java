package com.accenture.cvrd.framework.model.dao;

/**
 * Operador booleano <i>OU</i>.
 * 
 * @author ricardo.goes
 * 
 */
public class OrBooleanOperator implements BooleanOperator {

	/**
	 * construtor default
	 */
	public OrBooleanOperator() {
		super();
	}

	/**
	 * Sintaxe SQL do operador
	 * 
	 * @return a sintaxe SQL do operador
	 */
	public String toString() {
		return " or ";
	}

}
