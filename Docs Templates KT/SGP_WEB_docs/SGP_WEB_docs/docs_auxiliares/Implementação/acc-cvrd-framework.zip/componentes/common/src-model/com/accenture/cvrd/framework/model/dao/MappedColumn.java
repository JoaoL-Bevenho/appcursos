package com.accenture.cvrd.framework.model.dao;

import com.accenture.cvrd.framework.util.StringHelper;

/**
 * <p>
 * Coluna de uma tabela da base de dados, mapeada para um atributo de uma classe
 * da camada de persist�ncia.
 * </p>
 * <p>
 * Usada nas classes derivadas de <code>MappingQuery</code> para fazer o
 * mapeamento entre reposit�rio de dados e classes de persist�ncia.
 * </p>
 * 
 * @author ricardo.goes
 * @see com.accenture.cvrd.framework.model.dao.MappingQuery
 */
public class MappedColumn {

	public static final boolean DAO_GENERATED_SEQUENCE = true;

	private static final String ERRO_NOME_DA_SEQU�NCIA_NULO = "Nome da sequ�ncia � obrigat�rio quando configurada para ser gerada pelo DAO";

	public static final boolean NOT_DAO_GENERATED_SEQUENCE = false;

	/**
	 * <p>
	 * Cria um array de <code>MappedColumn</code> a partir de uma �nica
	 * coluna. S�o usados os defaults da classe <code>MappedColumn</code> para
	 * o item do array gerado.
	 * </p>
	 * 
	 * @param coluna
	 *            nome da coluna
	 * 
	 * @return array com um �nico objeto <code>MappedColumn</code>
	 */
	public static MappedColumn[] createArray(String coluna) {
		return createArray(new String[] { coluna });
	}

	/**
	 * Cria array de colunas a partir dos nomes fornecidos. Os defaults da
	 * classe <code>MappedColumn</code> s�o assumidos.
	 * 
	 * @param columns
	 *            nomes das colunas a serem criadas
	 * 
	 * @return array de colunas
	 */
	public static MappedColumn[] createArray(String[] columns) {
		MappedColumn[] mc = new MappedColumn[columns.length];

		for (int i = 0; i < columns.length; i++) {
			mc[i] = new MappedColumn(columns[i]);
		}
		return mc;
	}

	/**
	 * <p>
	 * Extrai os nomes das colunas em <code>pkColumns</code> para um array de
	 * <code>String</code>.
	 * </p>
	 * 
	 * @param pkColumns
	 * @return
	 */
	public static String[] extractColumnNames(MappedColumn[] pkColumns) {
		String[] names = new String[pkColumns.length];

		for (int i = 0; i < pkColumns.length; i++) {
			names[i] = pkColumns[i].getName();
		}

		return names;
	}

	private boolean daoGenerated = false;

	private String name;

	private String sequenceName;

	/**
	 * <p>
	 * Construtor para coluna assumindo defaults
	 * </p>.
	 * 
	 * @param name
	 */
	public MappedColumn(String name) {
		this.name = name;
	}

	/**
	 * <p>
	 * Construtor para coluna que usa <code>sequence</code> no banco de dados.
	 * </p>
	 * 
	 * @param name
	 * @param sequenceName
	 */
	public MappedColumn(String name, String sequenceName) {
		this(name);
		this.sequenceName = sequenceName;
	}

	/**
	 * <p>
	 * Construtor para coluna que usa <code>sequence</code> no banco de dados.
	 * Tem op��o para configurar gera��o de sequence pelo DAO.
	 * </p>
	 * <p>
	 * Para que o mecanismo de gera��o de colunas pelo DAO funcione � necess�rio
	 * implementar o m�todo <code>mapGeneratedKeys()</code> na classe da query
	 * que popula o TO com o valor gerado.
	 * </p>
	 * 
	 * @param name
	 *            nome da coluna
	 * @param sequenceName
	 *            nome da sequence no banco de dados
	 * @param daoGenerated
	 *            <code>true</code> caso a coluna tenha que ser gerada pelo
	 *            DAO, e <code>false</code> caso contr�rio (ex: trigger no
	 *            banco)
	 * 
	 * @see com.accenture.cvrd.framework.model.dao.MappingQuery#mapGeneratedKeys(java.util.HashMap,
	 *      Object)
	 */
	public MappedColumn(String name, String sequenceName, boolean daoGenerated) {
		this(name, sequenceName);

		if (daoGenerated && StringHelper.isEmpty(sequenceName)) {
			throw new IllegalArgumentException(ERRO_NOME_DA_SEQU�NCIA_NULO);
		}

		this.daoGenerated = daoGenerated;
	}

	/**
	 * Retorna o nome da coluna no reposit�rio
	 * 
	 * @return
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Retorna o nome da 'sequence' do Oracle que gera valores para a coluna
	 * 
	 * @return
	 */
	public String getSequenceName() {
		return this.sequenceName;
	}

	/**
	 * Retorna true caso a coluna tenha uma 'sequence' do Oracle associada a ela
	 */
	public boolean hasSequence() {
		return !StringHelper.isEmpty(this.sequenceName);
	}

	/**
	 * <p>
	 * Retorna true quando a coluna tem seu valor gerado automaticamente pela
	 * framework na chamada do m�todo <code>MappingQuerry.insert()</code>.
	 * </p>
	 */
	public boolean isDaoGenerated() {
		return this.daoGenerated;
	}
}
