package com.accenture.cvrd.framework.model.dao;

import com.accenture.cvrd.framework.util.EmptyArray;

/**
 * Crit�rio de N�O igualdade para ser aplicado em uma coluna.
 *  
 * @author marcelo.braga
 * 
 */
public class ColumnNotEqualsCriteria  extends ColumnCriteria  {

    private Object value;

    /**
     * Construtor
     * 
     * @param column
     *            nome da coluna onde o crit�rio � aplicado
     * @param value
     *            Valor a ser comparado com a coluna na cl�usula WHERE
     */
    public ColumnNotEqualsCriteria(String column, Object value) {
        super(column);
        this.value = value;
    }

    /**
     * 
     * @param column
     *            nome da coluna onde o crit�rio � aplicado
     * @param value
     *            Valor a ser comparado com a coluna na cl�usula WHERE
     * 
     * @param booleanOperator
     *            operador booleano usado para conectar o crit�rio ao crit�rio
     *            anterior caso exista.
     */
    public ColumnNotEqualsCriteria(String column, Object value, BooleanOperator booleanOperator) {
        super(column);
        this.value = value;
        this.setOperadorBooleano(booleanOperator);
    }

    /**
     * getter para o valor a ser aplicado no crit�rio
     * 
     * @return
     */
    public Object getValue() {
        return this.value;
    }

    /**
     * @see ColumnCriteria#getApplicableValues()
     */
    public Object[] getApplicableValues() {
        return (isNull(value) ? EmptyArray.OBJECT : new Object[] { value });
    }

    /**
     * @see ColumnCriteria#render(CriteriaRenderer)
     */
    public String render(CriteriaRenderer criteriaRenderer) {
        return criteriaRenderer.renderCriteria(this);
    }

}
