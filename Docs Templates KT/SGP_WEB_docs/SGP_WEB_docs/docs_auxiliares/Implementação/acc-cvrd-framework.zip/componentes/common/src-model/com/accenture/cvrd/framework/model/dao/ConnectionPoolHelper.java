package com.accenture.cvrd.framework.model.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.cvrd.framework.db.pool.ConnectionPool;

import com.accenture.cvrd.framework.util.ResourceUtil;
import com.accenture.cvrd.framework.util.StringHelper;

public class ConnectionPoolHelper {

	private static Log logger = LogFactory.getLog(ConnectionPoolHelper.class);

    private static boolean testMode = false;

	public static final String DEFAULT_DATASOURCE_RESOURCE_KEY = "_nls.datasource.default.key";

	public static final String DEFAULT_DATASOURCE_KEY = ResourceUtil.getResourceMessage(DEFAULT_DATASOURCE_RESOURCE_KEY);
	
	public static ConnectionPool getConnectionPool() {
		return getConnectionPool(null);
	}

	public static ConnectionPool getConnectionPool(String dataSourceKey) {
		ConnectionPool connectionPool = null;

		if (dataSourceKey == null) {
			dataSourceKey = DEFAULT_DATASOURCE_KEY;
		}

		dataSourceKey = dataSourceKey.concat(testMode ? "_test" : "");
		
		if (StringHelper.isBlank(dataSourceKey)) {
			// sem pool default configurado.
			// Retorna a inst�ncia do pool de conex�es padr�o
			connectionPool = ConnectionPool.getInstance();
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Obtendo contexto para o Pool ".concat(dataSourceKey));
			}

			connectionPool = ConnectionPool.getInstance(dataSourceKey);
		}

		return connectionPool;
	}
	
	public static void setTestMode(boolean onOff) {
	    testMode  = onOff;
	}
}
