package com.accenture.cvrd.framework.model.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.accenture.cvrd.framework.model.dao.exception.PersistenceException;
import com.accenture.cvrd.framework.util.ResourceUtil;

/**
 * Singleton que gerencia as conex�es com a base de dados. A base � obtida por
 * JNDI, conforme configura��o da aplica��o em arquivo de propriedades.
 * 
 * @author ricardo.goes
 * @deprecated usar a classe ConnectionPoolHelper que utiliza a fwk da cvrd
 */
public class ConnectionManager {
	private Log logger = LogFactory.getLog(ConnectionManager.class);

	private static final String DATASOURCE = ResourceUtil.getResourceMessage("_nls.datasource.jndi.name");

	private DataSource dataSource;

	private static ConnectionManager _instance;

	/**
	 * Construtor privado. Inicializa o gerenciador de conex�es.
	 * 
	 * @throws NamingException
	 */
	private ConnectionManager() throws NamingException {
		if (logger.isDebugEnabled()) {
			logger.debug("Obtendo contexto para o DataSource " + DATASOURCE);
		}

		Context ic = new InitialContext();
		DataSource ds = (DataSource) ic.lookup(DATASOURCE);
		this.dataSource = ds;
	}

	/**
	 * Construtor privado. Inicializa o gerenciador de conex�es usando um
	 * <code>InitialContext</code>. �til para teste unit�rio de classes que
	 * usam conex�o com o banco, onde n�o existe o contexto do container J2EE.
	 * 
	 * @param ic
	 *            InitialContext
	 * @throws NamingException
	 */
	private ConnectionManager(Context ic) throws NamingException {
		if (logger.isDebugEnabled()) {
			logger.debug("Obtendo contexto para o DataSource " + DATASOURCE);
		}

		DataSource ds = (DataSource) ic.lookup(DATASOURCE);
		this.dataSource = ds;
	}

	/**
	 * Construtor privado. Inicializa o gerenciador de conex�es usando um
	 * <code>DataSource</code>. �til para teste unit�rio do gerenciador.
	 * 
	 * @param dataSource
	 */
	private ConnectionManager(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * Obt�m a inst�ncia do singleton.
	 * 
	 * @return inst�ncia do singleton.
	 */
	public static ConnectionManager getInstance() {
		if (_instance == null) {
			synchronized (ConnectionManager.class) {
				if (_instance == null) {
					try {
						_instance = new ConnectionManager();
					} catch (NamingException e) {
						throw new PersistenceException("Erro ao obter Connection Manager", e);
					}
				}
			}
		}
		return _instance;
	}

	/**
	 * Obt�m uma inst�ncia do singleton. Inicializa o gerenciador de conex�es
	 * usando um <code>DataSource</code>. �til para teste unit�rio do
	 * gerenciador.
	 * 
	 * @param dataSource
	 * @return
	 */
	public static ConnectionManager getInstance(DataSource dataSource) {
		if (_instance == null) {
			synchronized (ConnectionManager.class) {
				if (_instance == null) {
					_instance = new ConnectionManager(dataSource);
				}
			}
		}
		return _instance;
	}

	/**
	 * Obt�m uma inst�ncia do singleton. Inicializa o gerenciador de conex�es
	 * usando um <code>InitialContext</code>. �til para teste unit�rio de
	 * classes que usam conex�o com o banco, onde n�o existe o contexto do
	 * container J2EE.
	 * 
	 * @param ic
	 * @return
	 */
	public static ConnectionManager getInstance(Context ic) {
		if (_instance == null) {
			synchronized (ConnectionManager.class) {
				if (_instance == null) {
					try {
						_instance = new ConnectionManager(ic);
					} catch (NamingException e) {
						throw new PersistenceException("Erro ao obter Connection Manager", e);
					}
				}
			}
		}

		return _instance;
	}

	/**
	 * Bloqueia o m�todo <code>clone()</code> para garantir o singleton.
	 */
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	/**
	 * Obt�m uma conex�o com o banco. O AutoCommit � desligado para garantir
	 * consist�ncia das transa��es.
	 * 
	 * @return conex�o com o banco
	 */
	public Connection getConnection() {
		try {
			Connection connection = this.getDataSource().getConnection();
			connection.setAutoCommit(false);
			return connection;
		} catch (SQLException e) {
			throw new PersistenceException(e);
		}
	}

	/**
	 * Libera os recursos de banco e JDBC associados � conex�o
	 * <code>connection</code>.
	 * 
	 * @param connection
	 *            Conex�o a ser dispensada.
	 */
	public void release(Connection connection) {
		try {
			connection.close();
		} catch (SQLException e) {
			throw new PersistenceException(e);
		}
	}

	/**
	 * Informa o <code>DataSource</code> usado pelo gerenciador de conex�es.
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * Obt�m o <code>DataSource</code> usado pelo gerenciador de conex�es.
	 * 
	 * @return
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}
}
