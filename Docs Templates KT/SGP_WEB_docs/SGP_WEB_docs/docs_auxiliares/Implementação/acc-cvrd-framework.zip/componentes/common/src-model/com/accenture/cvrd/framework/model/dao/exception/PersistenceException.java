package com.accenture.cvrd.framework.model.dao.exception;

import com.accenture.cvrd.framework.exception.SystemException;

/**
 * Exce��o ocorrida na camada de persist�ncia.
 * 
 * @author ricardo.goes
 * 
 */
public class PersistenceException extends SystemException {

	private static final long serialVersionUID = 1L;

	/**
	 * Construtor default
	 * 
	 */
	public PersistenceException() {
		super();
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 * @param cause
	 *            causa da exce��o
	 */
	public PersistenceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Construtor
	 * 
	 * @param message
	 *            mensagem descritiva da exce��o
	 */
	public PersistenceException(String message) {
		super(message);
	}

	/**
	 * Construtor
	 * 
	 * @param cause
	 *            causa da exce��o
	 */
	public PersistenceException(Throwable cause) {
		super(cause);
	}
}
