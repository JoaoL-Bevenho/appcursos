package com.accenture.cvrd.framework.model.dao;

/**
 * Interface para um renderizador de crit�rios de filtro. Permite aplicar v�rios
 * tipos de crit�rio.
 * 
 * @author ricardo.goes
 * 
 */
public interface CriteriaRenderer {

	/**
	 * Renderiza crit�rio de igualdade.
	 * 
	 * @param criteria
	 *            crit�rio de igualdade
	 * @return crit�rio renderizado
	 */
	String renderCriteria(final ColumnEqualsCriteria criteria);
	
	/**
	 * Renderiza crit�rio de N�O igualdade.
     * 
     * @param criteria
     *            crit�rio de igualdade
     * @return crit�rio renderizado
     */
    String renderCriteria(final ColumnNotEqualsCriteria criteria);

	/**
	 * Renderiza crit�rio de m�scara de compara��o.
	 * 
	 * @param criteria
	 *            crit�rio de m�scara de compara��o
	 * @return crit�rio renderizado
	 */
	String renderCriteria(final ColumnLikeCriteria criteria);

	/**
	 * Renderiza crit�rio de m�scara de compara��o.
	 * 
	 * @param criteria
	 *            crit�rio de m�scara de compara��o
	 * @return crit�rio renderizado
	 */
	String renderCriteria(final ColumnLikeWithCaseIgnoreCriteria criteria);

	/**
	 * Renderiza crit�rio de faixa de valores.
	 * 
	 * @param criteria
	 *            crit�rio de faixa de valores
	 * @return crit�rio renderizado
	 */
	String renderCriteria(final ColumnRangeCriteria criteria);

	/**
	 * Renderiza crit�rio gen�rico.
	 * 
	 * @param criteria
	 *            crit�rio gen�rico
	 * @return crit�rio renderizado
	 */
	String renderCriteria(final QueryRawCriteria criteria);

	/**
	 * Renderiza crit�rio de compara��o com lista de valores poss�veis.
	 * 
	 * @param criteria
	 *            crit�rio de compara��o com lista de valores poss�veis
	 * 
	 * @return crit�rio renderizado
	 */
	String renderCriteria(final ColumnInCriteria criteria);

    /**
     * Renderiza crit�rio de compara��o com lista de valores poss�veis.
     * 
     * @param criteria
     *            crit�rio de compara��o com lista de valores poss�veis
     * 
     * @return crit�rio renderizado
     */
    String renderCriteria(final ColumnNotInCriteria criteria);

	/**
	 * Renderiza crit�rio de join entre colunas.
	 * 
	 * @param criteria
	 *            crit�rio de join entre colunas
	 * 
	 * @return crit�rio renderizado
	 */
	String renderCriteria(final ColumnJoinCriteria criteria);
}
