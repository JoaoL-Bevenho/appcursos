package com.accenture.cvrd.framework.model.dao;

import com.accenture.cvrd.framework.util.StringHelper;

/**
 * Crit�rio de igualdade para ser aplicado entre colunas das tabelas consultadas
 * na query
 * 
 * @author ricardo.goes
 * 
 */
public class ColumnJoinCriteria extends QueryCriteria {

	private String oneColumn;

	private String otherColumn;

	/**
	 * Construtor
	 * 
	 * @param oneColumn
	 *            primeira coluna do join
	 * @param otherColumn
	 *            segunda coluna do join
	 */
	public ColumnJoinCriteria(String oneColumn, String otherColumn) {
		this.oneColumn = oneColumn;
		this.otherColumn = otherColumn;
	}

	/**
	 * @see QueryCriteria#isApplicable()
	 */
	public boolean isApplicable() {
		return !StringHelper.isBlank(this.oneColumn) && !StringHelper.isBlank(this.otherColumn);
	}

	/**
	 * @see QueryCriteria#render(CriteriaRenderer)
	 */
	public String render(CriteriaRenderer criteriaRenderer) {
		return criteriaRenderer.renderCriteria(this);
	}

	/**
	 * uma das colunas do join
	 * 
	 * @return uma coluna do join
	 */
	public String getOneColumn() {
		return this.oneColumn;
	}

	/**
	 * a outra coluna do join
	 * 
	 * @return outra coluna do join
	 */
	public String getOtherColumn() {
		return this.otherColumn;
	}
}
