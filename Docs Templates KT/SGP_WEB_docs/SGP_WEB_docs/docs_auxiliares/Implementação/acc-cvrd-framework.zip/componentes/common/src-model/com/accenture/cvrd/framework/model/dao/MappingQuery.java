package com.accenture.cvrd.framework.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.accenture.cvrd.framework.model.dao.exception.ObjectNotFoundException;
import com.accenture.cvrd.framework.model.dao.exception.PersistenceException;
import com.accenture.cvrd.framework.util.DataFilter;
import com.accenture.cvrd.framework.util.DataPagination;
import com.accenture.cvrd.framework.util.EmptyArray;

/**
 * <p>
 * Query para acesso a dados reutiliz�vel. As subclasses concretas precisam
 * implementar o m�todo abstrato <code>mapRow</code> para converter cada linha
 * do <code>ResultSet</code> JDBC em um <i>Transfer Object</i>.
 * </p>
 * 
 * <p>
 * S�o fornecidos m�todos default para execu��o da query, com ou sem par�metros.
 * </p>
 * 
 * @author ricardo.goes, luiz.esmiralha
 * @see com.accenture.cvrd.framework.model.dao.MappedColumn
 * @see DataFilter
 * @see DataPagination
 */
public abstract class MappingQuery implements IMappingQuery {

    private static final String ERRO_QUERY_INTRO = "Falha ao executar a query: ";

    private static final String MSG_ERRO_UTILIZACAO_QUERY_NAO_INFORMADA = "A query a ser executada n�o foi informada."
            + " Use o construtor para informar a query, ou um m�todo de execu��o que receba a query como par�metro";

    private static final String QUERY_BY_KEY_RETURNED_MULTIPLE_ROWS = "A consulta por chave retornou mais de uma ocorr�ncia";

    protected static Map sqlDeleteMap = new HashMap();

    protected static Map sqlFindAllMap = new HashMap();

    protected static Map sqlFindByKeyMap = new HashMap();

    protected static Map sqlInsertMap = new HashMap();

    protected static Map sqlUpdateMap = new HashMap();

    private Log logger = LogFactory.getLog(MappingQuery.class);

    private PreparedStatement ps;

    protected MappedColumn[] pkColumns;

    protected MappedColumn[] nonPkColumns;

    /**
     * Construtor indicado para queries que n�o ser�o reutilizadas.
     */
    public MappingQuery() {
        super();
        this.initColumns();
    }

    /**
     * Nas implementa��es de <code>MappingQuery</code> este m�todo deve
     * inicializar os atributos <code>pkColumns</code> e
     * <code>nonPkColumns</code>.
     * 
     */
    protected abstract void initColumns();

    /**
     * Construtor de uma query reutiliz�vel. A query pode ser executada quantas
     * vezes for necess�rio, podendo receber novos par�metros a cada execu��o.
     * 
     * � feito um cache do <code>PreparedStatement</code>, para reutiliza��o
     * em v�rias execu��es. Os recursos alocados s�o liberados na destru��o da
     * inst�ncia pelo <i>Garbage collector</i>. O m�todo release() pode ser
     * usado para for�ar a libera��o dos recursos.
     * 
     * @param sql
     *            Query a ser executada
     * @param status
     */
    public MappingQuery(String sql, Connection status) {
        try {
            ps = status.prepareStatement(sql);
        } catch (SQLException e) {
            throw new PersistenceException(ERRO_QUERY_INTRO, e);
        }
    }

    /**
     * Apaga o objeto representado pelo objeto de transfer�ncia <code>to</code>
     * da base de dados, de acordo com o mapeamento configurado.
     * 
     * @param to
     *            Objeto de transfer�ncia a ser exclu�do da base de dados
     * @param status
     *            conex�o com a base
     */
    public void deleteByKey(Object to, Connection status) {
        Object[] parametros = SqlDeleteQuery.prepareDeleteByKeyParameters(this.getPKParameters(to));

        deleteByKey(parametros, status);
    }

    /**
     * Apaga o objeto representado pela chave <code>key</code> da base de
     * dados, de acordo com o mapeamento configurado.
     * 
     * @param key
     *            Chave de identifica��o do objeto a ser exclu�do da base de
     *            dados
     * @param status
     *            conex�o com a base
     */
    public void deleteByKey(long key, Connection status) {
        deleteByKey(new Object[] { new Long(key) }, status);
    }

    /**
     * Apaga o objeto cuja chave � representado pelo array
     * <code>parametros</code>, de acordo com o mapeamento configurado.
     * 
     * @param parametros
     *            array que representa a chave do objeto a ser apagado
     * @param status
     *            conex�o com a base
     */
    private void deleteByKey(Object[] parametros, Connection status) {
        execute(getDeleteByKey(), parametros, status);
    }

    /**
     * Apaga o objeto encontrado pelo filtro de 
     * <code>colunas</code>.
     * 
     * @param columnNames array contendo os nomes das colunas utilizadas no filtro.
     * 
     * @param parametros
     *            array contento os valores das colunas, na mesma ordem.
     * @param status
     *            conex�o com a base
     */
    public void deleteByColumns(String[] columnNames, Object[] columnValues, Connection status) {
        execute(getDeleteByColumns(columnNames), columnValues, status);
    }

    /**
     * Executa a query reutiliz�vel.
     */
    public void execute() {
        execute(EmptyArray.OBJECT, EmptyArray.INT);
    }

    /**
     * Obt�m os dados da tabela mapeada pela query, obedecendo ao crit�rio de
     * filtro fornecido em <code>criteria</code>.
     * 
     * @param criteria
     *            Crit�rio de filtro
     * @param status
     *            Conex�o com a base
     * 
     * @return Lista com os dados encontrados
     */
    public List findByFilter(Criteria criteria, Connection status) {
        return findByFilter(criteria.toFilter(DataPagination.INATIVO), EmptyArray.STRING, status);
    }

    /**
     * Executa a query de consulta usando o filtro passado.
     * 
     * @param dataFilter
     *            crit�rios de filtro (colunas e valores)
     * @param status
     *            conex�o com a base
     * 
     * @return
     */
    public List findByFilter(DataFilter dataFilter, Connection status) {

        return findByFilter(dataFilter, EmptyArray.STRING, status);
    }

    /**
     * Obt�m os dados da tabela mapeada pela query, usando o filtro
     * <code>dataFilter</code>.
     * 
     * @param dataFilter
     *            crit�rios de filtro (colunas e valores)
     * @param orderByFields
     *            campos usados na ordena��o, por ordem de preced�ncia. Podem
     *            vir com a dire��o de ordena��o junto (ex: campo1 asc)
     * @param status
     *            conex�o com a base
     */
    public List findByFilter(DataFilter dataFilter, String[] orderByFields, Connection status) {

        String sqlString = getFindByFilter(dataFilter, orderByFields);

        return executeQuery(sqlString, dataFilter.getColumnValues(), status, dataFilter.getPagination());
    }

    /**
     * Obt�m a sintaxe da query de consulta baseada no uso do filtro
     * <code>dataFilter</code> e nos campos de ordena��o
     * <code>orderByFields</code>
     * 
     * @param dataFilter
     *            Filtro a ser aplicado na consulta
     * 
     * @param orderByFields
     *            campos usados na ordena��o, por ordem de preced�ncia. Podem
     *            vir com a dire��o de ordena��o junto (ex: campo1 asc)
     * @return
     */
    public String getFindByFilter(DataFilter dataFilter, String[] orderByFields) {
        SqlSelectQuery query = new SqlSelectQuery(getTable());
        query.setCriterias(dataFilter.getQueryCriterias());
        query.setOrderByFields(orderByFields);

        return query.toString();
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.IMappingQuery#findByColumns(java.lang.String[], java.lang.Object[], java.sql.Connection)
     */
    public List findByColumns(String[] columnNames, Object[] columnValues, Connection status) {
        return findByColumns(columnNames, columnValues, EmptyArray.STRING, status, DataPagination.INATIVO);
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.IMappingQuery#findByColumns(java.lang.String[], java.lang.Object[], java.lang.String[], java.sql.Connection)
     */
    public List findByColumns(String[] columnNames, Object[] columnValues, String[] orderByFields, Connection status) {
        return findByColumns(columnNames, columnValues, orderByFields, status, DataPagination.INATIVO);
    }

    /**
     * <p>
     * Executa a query de consulta com lista de par�metros. A ordem dos
     * par�metros na lista <code>columnValues</code> deve ser a mesma em que
     * os mesmos s�o encontrados na lista com os nomes das colunas a serem
     * filtradas em <code>columnNames</code>.
     * </p>
     * 
     * <p>
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * </p>
     * 
     * <p>
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRow</code>.
     * </p>
     * 
     * <p>
     * Os crit�rios de pagina��o encontrados no par�metro <code>paginacao</code>
     * s�o usados na cria��o do resultado da consulta. Somente as linhas
     * pertencentes � p�gina corrente s�o retornadas.
     * </p>
     * 
     * @param columnNames
     * @param columnValues
     *            Parametros passados para a query, na ordem em que aparecem em
     *            <code>columnNames</code>
     * @param status
     *            conex�o com a base
     * @param dataPagination
     *            crit�rios de pagina��o de dados
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
    private List findByColumns(String[] columnNames, Object[] columnValues, String[] orderByFields, Connection status,
            DataPagination dataPagination) {
        return executeQuery(new SqlSelectQuery(getTable(), columnNames, orderByFields).toString(), columnValues, status,
                dataPagination);
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.IMappingQuery#execute(java.lang.Object[])
     */
    public void execute(Object[] parametros) {
        this.execute(parametros, EmptyArray.INT);
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.IMappingQuery#execute(java.lang.Object[], int[])
     */
    public void execute(Object[] parametros, int[] types) {
        try {
            mapParameters(parametros, types);
            ps.execute();
        } catch (SQLException e) {
            throw new PersistenceException(ERRO_QUERY_INTRO, e);
        }
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.IMappingQuery#execute(java.lang.String, java.lang.Object[], java.sql.Connection)
     */
    public void execute(String sql, Object[] parametros, Connection con) {
        execute(sql, parametros, EmptyArray.INT, con);
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.IMappingQuery#execute(java.lang.String, java.lang.Object[], int[], java.sql.Connection)
     */
    public void execute(String sql, Object[] parametros, int[] types, Connection con) {
        PreparedStatement ps = null;

        try {
            if (logger.isDebugEnabled()) {
                logger.debug(this.getClass().getName().concat(": M�todo execute() - SQL: [").concat(sql).concat("] --Parametros: ")
                        .concat(objectArrayToString(parametros)));
            }

            ps = con.prepareStatement(sql);
            mapParameters(ps, parametros, types);
            ps.execute();

            if (logger.isDebugEnabled()) {
                logger.debug("M�todo execute() - rows afetados: " + ps.getUpdateCount());
            }

        } catch (SQLException e) {
            throw new PersistenceException(ERRO_QUERY_INTRO + (e.getMessage() != null ? e.getMessage() : "mensagem nula]"), e);
        } finally {
            release(ps);
        }
    }

    /**
     * Executa a query. Os dados s�o retornados numa lista. Cada item da lista �
     * populado pelo m�todo <code>mapRows</code>.
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
    public List executeQuery() {
        return executeQuery(EmptyArray.OBJECT, EmptyArray.INT);
    }

    /**
     * Executa a query com lista de par�metros. A ordem dos par�metros na lista
     * <code>parms</code> deve ser a mesma em que os mesmos s�o referenciados
     * na query <code>sql</code>.
     * 
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * 
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRows</code>.
     * 
     * @param parametros
     *            Parametros passados para a query, na ordem em que s�o
     *            referenciados
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
    public List executeQuery(Object parametros[]) {
        return executeQuery(parametros, EmptyArray.INT);
    }

    /**
     * Executa a query com lista de par�metros e respectivos tipos. A ordem dos
     * par�metros na lista <code>parms</code> deve ser a mesma em que os
     * mesmos s�o referenciados na query informada no construtor.
     * 
     * Os tipos informados para os par�metros em <code>types</code> s�o
     * definidos em {@link #java.sql.Types java.sql.Types}.
     * 
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRows</code>.
     * 
     * @param parametros
     *            Parametros passados para a query, na ordem em que s�o
     *            referenciados
     * @param types
     *            tipos dos par�metros
     * 
     * @return resultado da consulta
     */
    public List executeQuery(Object parametros[], int types[]) {
        return executeQuery(parametros, types, DataPagination.INATIVO);
    }

    /**
     * Executa a query com lista de par�metros e respectivos tipos. A ordem dos
     * par�metros na lista <code>parms</code> deve ser a mesma em que os
     * mesmos s�o referenciados na query informada no construtor.
     * 
     * Os tipos informados para os par�metros em <code>types</code> s�o
     * definidos em {@link #java.sql.Types java.sql.Types}.
     * 
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRows</code>.
     * 
     * @param parametros
     *            Parametros passados para a query, na ordem em que s�o
     *            referenciados
     * @param types
     *            tipos dos par�metros
     * @param dataPagination
     *            Crit�rios de pagina��o de dados
     * 
     * @return resultado da consulta
     */
    public List executeQuery(Object parametros[], int types[], DataPagination dataPagination) {

        if (ps == null) {
            throw new NullPointerException(MSG_ERRO_UTILIZACAO_QUERY_NAO_INFORMADA);
        }

        ResultSet rs = null;
        List objects;

        try {
            mapParameters(parametros, types);
            rs = ps.executeQuery();
            objects = resultSetToList(rs, dataPagination);

            return objects;
        } catch (SQLException e) {
            throw new PersistenceException(ERRO_QUERY_INTRO, e);
        } finally {
            release(rs);
        }
    }

    /**
     * Executa a query com lista de par�metros. A ordem dos par�metros na lista
     * <code>parms</code> deve ser a mesma em que os mesmos s�o referenciados
     * na query <code>sql</code>.
     * 
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * 
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRow</code>.
     * 
     * @param sql
     *            Query a ser executada
     * @param parametros
     *            Parametros passados para a query, na ordem em que s�o
     *            referenciados
     * @param con
     *            Conex�o com o banco
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
    public List executeQuery(String sql, Object[] parametros, Connection connection) {
        return executeQuery(sql, parametros, connection, DataPagination.INATIVO);
    }

    /**
     * Converte um array de objetos para um string contendo uma lista de valores
     * separada por '|'.
     * 
     * @param parametros
     *            valores a serem convertidos em string com separador
     * 
     * @return string com os valores separados por '|'
     */
    private String objectArrayToString(Object[] parametros) {
        StringBuffer s = new StringBuffer("[");

        if (parametros != null) {
            for (int i = 0; i < parametros.length; i++) {
                if (i != 0) {
                    s.append("|");
                }

                if (parametros[i] != null) {
                    s.append(parametros[i].toString());
                }
            }
        }

        return s.append("]").toString();
    }

    /**
     * Executa a query informada em <code>sql</code>.
     * 
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRow</code>.
     * 
     * @param sql
     *            Query a ser executada
     * @param con
     *            Conex�o com o banco
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
    public List executeQuery(String sql, Connection con) {
        return this.executeQuery(sql, EmptyArray.OBJECT, con);
    }

    /**
     * Garante a libera��o dos recursos JDBC alocados na destru��o do objeto.
     */
    protected void finalize() throws Throwable {
        this.release();
        super.finalize();
    }

    /**
     * Obt�m todas as ocorr�ncias da base de dados para o objeto mapeado pela
     * query.
     * 
     * @param status
     *            conex�o com a base
     */
    public List findAll(Connection status) {
        return findAll(new String[0], status, new DataPagination());
    }

    /**
     * Obt�m todas as ocorr�ncias da base de dados para o objeto mapeado pela
     * query, com possibilidade de ordena��o e pagina��o
     * 
     * @param orderByFields
     *            campos usados na ordena��o, por ordem de preced�ncia. Podem
     *            vir com a dire��o de ordena��o junto (ex: campo1 asc)
     * @param dataPagination
     *            crit�rios de pagina��o de dados
     * @param status
     *            conex�o com a base
     */
    public List findAll(String[] orderByFields, Connection status, DataPagination pagination) {
        return executeQuery(getFindAll(orderByFields), status, pagination);
    }

    /**
     * Obt�m todas as ocorr�ncias da base de dados para o objeto mapeado pela
     * query, com possibilidade de ordena��o.
     * 
     * @param orderByFields
     *            campos usados na ordena��o, por ordem de preced�ncia. Podem
     *            vir com a dire��o de ordena��o junto (ex: campo1 asc)
     * @param status
     *            conex�o com a base
     */
    public List findAll(String[] orderByFields, Connection status) {
        return findAll(orderByFields, status, new DataPagination());
    }

    /**
     * Obt�m todas as ocorr�ncias da base de dados para o objeto mapeado pela
     * query, com possibilidade de pagina��o
     * 
     * @param dataPagination
     *            crit�rios de pagina��o de dados
     * @param status
     *            conex�o com a base
     */
    public List findAll(Connection status, DataPagination pagination) {
        return findAll(new String[0], status, pagination);
    }

    /**
     * Executa a query de consulta <code>sql</code>, com recurso de
     * pagina��o.
     * 
     * @param sql
     *            query de consulta a ser executada
     * @param status
     *            conex�o com a base
     * @param pagination
     *            crit�rios de pagina��o de dados
     * 
     * @return resultado da consulta
     */
    public List executeQuery(String sql, Connection status, DataPagination pagination) {
        return executeQuery(sql, EmptyArray.OBJECT, status, pagination);
    }

    /**
     * <p>
     * Encontra o objeto cuja chave est� representada pelo objeto de
     * transfer�ncia <code>to</code> de acordo com o mapeamento configurado.
     * </p>
     * 
     * @param to
     *            Objeto de transfer�ncia a ser exclu�do da base de dados
     * @param status
     *            conex�o com a base
     * @return
     */
    public Object findByKey(Object to, Connection status) {
        return findByKey(SqlSelectQuery.prepareFindByKeyParameters(getPKParameters(to)), status);
    }

    /**
     * <p>
     * Encontra o objeto identificado pela chave <code>key</code> de acordo
     * com o mapeamento configurado.
     * </p>
     * 
     * @param key
     *            chave de identifica��o do objeto a ser encontrado na base
     * @param status
     *            conex�o com a base
     * 
     * @return objeto encontrado com a chave fornecida
     */
    public Object findByKey(long key, Connection status) {
        return findByKey(new Object[] { new Long(key) }, status);
    }

    /**
     * <p>
     * Encontra o objeto identificado pela chave <code>parameters</code> de
     * acordo com o mapeamento configurado.
     * </p>
     * 
     * @param parameters
     *            campos que formam a chave de identifica��o do objeto a ser
     *            encontrado na base
     * @param status
     *            conex�o com a base
     * 
     * @return objeto identificado pela chave fornecida
     */
    private Object findByKey(Object[] parameters, Connection status) {
        return executeForObject(getFindByKey(), parameters, status);
    }

    /**
     * Executa a query <code>sql</code>, retornando um �nico objeto
     * 
     * @param sql
     *            query a ser executada
     * @param parameters
     *            par�metros utilizados pela query
     * @param status
     *            conex�o com a base
     * 
     * @return objeto retornado pela query
     */
    protected Object executeForObject(String sql, Object[] parameters, Connection status) {

        List l = executeQuery(sql, parameters, status);

        Iterator i = l.iterator();

        if (i.hasNext()) {
            Object o = i.next();

            // s� esperamos obter uma ocorr�ncia
            if (i.hasNext()) {
                throw new PersistenceException(QUERY_BY_KEY_RETURNED_MULTIPLE_ROWS);
            }

            return o;
        }

        throw new ObjectNotFoundException();
    }

    /**
     * <p>
     * Obt�m o comando SQL de <code>DELETE</code> usando a chave como filtro,
     * para o mapeamento fornecido pela query. � feito um cache para
     * reutiliza��o do comando nas chamadas seguintes desse m�todo.
     * </p>
     * 
     * @return string com o SQL de DELETE filtrado pela chave
     */
    public String getDeleteByKey() {
        String cacheId = this.getSyntaxCacheId();

        if (sqlDeleteMap.get(cacheId) == null) {
            sqlDeleteMap.put(cacheId, new SqlDeleteQuery(getTable(), getPkColumns()).toString());
        }

        return sqlDeleteMap.get(cacheId).toString();
    }

    /**
     * <p>
     * Obt�m o comando SQL de <code>DELETE</code> usando colunas como filtro,
     * para o mapeamento fornecido pela query. � feito um cache para
     * reutiliza��o do comando nas chamadas seguintes desse m�todo.
     * </p>
     * 
     * @return string com o SQL de DELETE filtrado por colunas.
     */
    public String getDeleteByColumns(String[] columnNames) {
        return new SqlDeleteQuery(getTable(), columnNames).toString();
    }

    /**
     * <p>
     * Retorna o identificador da query para uso pelo mecanismo de cache. Pode
     * ser sobreescrito quando o nome da classe n�o identifica unicamente a
     * query.
     * </p>
     * 
     * @return identificador da sintaxe da query mantida em cache
     */
    protected String getSyntaxCacheId() {
        return this.getClass().getName();
    }

    /**
     * <p>
     * Obt�m o comando SQL de <code>SELECT</code> sem filtro, para o
     * mapeamento fornecido pela query. � feito um cache para reutiliza��o do
     * comando nas chamadas seguintes desse m�todo.
     * </p>
     * 
     * @return string com o SQL de SELECT
     */
    public String getFindAll() {
        return getCachedFindAll();
    }

    /**
     * Obt�m a sintaxe da consulta <code>findAll</code>. Uma vez obtida, a
     * sintaxe fica em cache para as pr�ximas utiliza��es.
     * 
     * @return sintaxe da consulta <code>findAll</code>
     */
    private String getCachedFindAll() {
        String cacheId = this.getSyntaxCacheId();

        if (sqlFindAllMap.get(cacheId) == null) {
            String sql = composeFindAll(null);
            sqlFindAllMap.put(cacheId, sql);
        }

        return sqlFindAllMap.get(cacheId).toString();
    }

    /**
     * Obt�m a sintaxe da consulta <code>findAll</code>. Uma vez obtida, a
     * sintaxe fica em cache para as pr�ximas utiliza��es. Tem recurso para
     * campos de ordena��o
     * 
     * @param orderByFields
     *            campos usados na ordena��o, por ordem de preced�ncia. Podem
     *            vir com a dire��o de ordena��o junto (ex: campo1 asc)
     * 
     * @return sintaxe da consulta <code>findAll</code>
     */
    private String getFindAll(String[] orderByFields) {

        // sem orderby? usa o cache
        if (orderByFields.length == 0) {
            return getCachedFindAll();
        }

        return composeFindAll(orderByFields);
    }

    /**
     * Monta a sintaxe da query de <code>findAll</code> de acordo com o
     * mapeamento. Tem recurso para crit�rios de ordena��o.
     * 
     * @param orderByFields
     *            campos usados na ordena��o, por ordem de preced�ncia. Podem
     *            vir com a dire��o de ordena��o junto (ex: campo1 asc)
     * 
     * @return sintaxe da query de <code>findAll</code>
     */
    private String composeFindAll(String[] orderByFields) {
        if (orderByFields == null) {
            orderByFields = EmptyArray.STRING;
        }

        SqlSelectQuery q = new SqlSelectQuery(getTable(), EmptyArray.STRING, orderByFields);
        q.setPkColumns(getPkColumns());
        q.setNonPkColumns(getNonPkColumns());

        return q.toString();
    }

    /**
     * <p>
     * Obt�m o comando SQL de <code>SELECT</code> usando a chave como filtro,
     * para o mapeamento fornecido pela query. � feito um cache para
     * reutiliza��o do comando nas chamadas seguintes desse m�todo.
     * </p>
     * 
     * @return string com o SQL de SELECT filtrado pela chave
     */
    public String getFindByKey() {
        String cacheId = this.getSyntaxCacheId();

        if (sqlFindByKeyMap.get(cacheId) == null) {
            sqlFindByKeyMap.put(cacheId, new SqlSelectQuery(getTable(), getPkColumns()).toString());
        }

        return sqlFindByKeyMap.get(cacheId).toString();
    }

    /**
     * <p>
     * Obt�m o comando SQL de <code>INSERT</code> para o mapeamento fornecido
     * pela query. � feito um cache para reutiliza��o do comando nas chamadas
     * seguintes desse m�todo.
     * </p>
     * 
     * @return string com o SQL de INSERT filtrado pela chave
     */
    public String getInsert() {
        String cacheId = this.getSyntaxCacheId();

        if (sqlInsertMap.get(cacheId) == null) {
            sqlInsertMap.put(cacheId, new SqlInsertQuery(getTable(), getPkColumns(), getNonPkColumns()).toString());
        }

        return sqlInsertMap.get(cacheId).toString();
    }

    /**
     * Retorna o array com as colunas mapeadas na query que n�o fazem parte da
     * chave prim�ria.
     * 
     * @return array com as colunas mapeadas na query que n�o fazem parte da
     *         chave prim�ria
     */
    protected MappedColumn[] getNonPkColumns() {
        return this.nonPkColumns;
    }

    /**
     * Valores das colunas contidas no TO correspondentes �s colunas
     * configuradas no campo <code>nonPkColumns</code>.
     * 
     * @param transferObject
     *            TO com os dados a serem extra�dos
     * 
     * @return Valores das colunas que n�o fazem parte da chave
     */
    protected abstract Object[] getNonPKParameters(Object transferObject);

    /**
     * Retorna o array com as colunas mapeadas na query que fazem parte da chave
     * prim�ria.
     * 
     * @return array com as colunas mapeadas na query que fazem parte da chave
     *         prim�ria
     */
    protected MappedColumn[] getPkColumns() {
        return this.pkColumns;
    }

    /**
     * Retorna os valores das colunas contidas no TO correspondentes �s colunas
     * configuradas no campo <code>pkColumns</code>.
     * 
     * @param transferObject
     *            TO com os dados a serem extra�dos
     * 
     * @return array com os valores que formam a chave do objeto mapeado pela
     *         query
     */
    protected abstract Object[] getPKParameters(Object transferObject);

    /**
     * Retorna os nomes de todas as colunas mapeadas pela query
     * 
     * @return array com os nomes de todas as colunas mapeadas pela query
     */
    protected String[] getAllColumnNames() {
        MappedColumn[] pkCols = getPkColumns();
        MappedColumn[] nonPkCols = getNonPkColumns();

        MappedColumn[] empty = new MappedColumn[] {};

        if (pkCols == null) {
            pkCols = empty;
        }
        if (nonPkCols == null) {
            nonPkCols = empty;
        }

        int size = pkCols.length + nonPkCols.length;
        String[] cols = new String[size];

        for (int i = 0; i < pkCols.length; i++) {
            cols[i] = pkCols[i].getName();
        }

        int base = pkCols.length;

        for (int i = 0; i < nonPkCols.length; i++) {
            cols[base + i] = nonPkCols[i].getName();
        }

        return cols;
    }

    /**
     * As implementa��es de <code>MappingQuery</code> devem retornar neste
     * m�todo o nome da tabela mapeada.
     * 
     * @return nome da tabela mapeada
     */
    protected abstract String getTable();

    /**
     * <p>
     * Obt�m o comando SQL de <code>UPDATE</code> usando a chave como filtro,
     * para o mapeamento fornecido pela query. � feito um cache para
     * reutiliza��o do comando nas chamadas seguintes desse m�todo.
     * </p>
     * 
     * @return string com o SQL de UPDATE
     */
    public String getUpdateByKey() {
        String cacheId = this.getSyntaxCacheId();

        if (sqlUpdateMap.get(cacheId) == null) {
            sqlUpdateMap.put(cacheId, new SqlUpdateQuery(getTable(), getPkColumns(), getNonPkColumns()).toString());
        }

        return sqlUpdateMap.get(cacheId).toString();
    }

    /**
     * Insere os dados do objeto de transfer�ncia <code>to</code> na base de
     * dados, de acordo com o mapeamento configurado. Os atributos do objeto de
     * tranfer�ncia que utilizam sequence s�o atualizados ap�s a inser��o.
     * 
     * @param to
     *            Objeto de transfer�ncia a ser inserido na base de dados
     * @param status
     *            conex�o com a base
     */
    public void insert(Object to, Connection status) {
        insert(to, EmptyArray.INT, status);
    }

    /**
     * Insere os dados do objeto de transfer�ncia <code>to</code> na base de
     * dados, de acordo com o mapeamento configurado. Os atributos do objeto de
     * tranfer�ncia que utilizam sequence s�o atualizados ap�s a inser��o.
     * 
     * @param to
     *            Objeto de transfer�ncia a ser inserido na base de dados
     * @param types
     *            tipos dos par�metros
     * @param status
     *            conex�o com a base
     */
    public void insert(Object to, int[] types, Connection status) {
        Object[] queryParameters = SqlInsertQuery.prepareQueryParameters(getPkColumns(), this.getPKParameters(to), this
                .getNonPKParameters(to));

        execute(getInsert(), queryParameters, types, status);

        fillWithGeneratedSequenceColumns(to, status);
    }

    /**
     * <p>
     * Atualiza os dados do objeto de transfer�ncia <code>to</code> na base de
     * dados, de acordo com o mapeamento configurado.
     * </p>
     * 
     * @param to
     *            Objeto de transfer�ncia a ser atualizado na base de dados
     * @param types
     *            tipos dos par�metros
     * @param status
     *            conex�o com a base
     */
    public void updateByKey(Object to, int[] types, Connection status) {
        Object[] parametros = SqlUpdateQuery.prepareUpdateByKeyParameters(this.getPKParameters(to), this.getNonPKParameters(to));
        execute(getUpdateByKey(), parametros, types, status);
    }

    /**
     * Preenche as colunas do objeto de transfer�ncia <code>to</code> que
     * foram configuradas para uso de sequence com os valores gerados.
     * 
     * @param to
     *            TO a ser preenchido com os valores obtidos de Sequence
     * @param status
     *            conex�o com a base
     */
    protected void fillWithGeneratedSequenceColumns(Object to, Connection status) {

        HashMap map = new HashMap();

        readSequenceCurrentValues(map, getPkColumns(), status);
        readSequenceCurrentValues(map, getNonPkColumns(), status);

        mapGeneratedKeys(map, to);
    }

    /**
     * M�todo implementado nas subclasses para preencher as colunas do objeto de
     * transfer�ncia <code>to</code> que foram configuradas para uso de
     * sequence com os valores gerados. Exemplo: <code>
     * 		<p>
     * 		GrupoEstabelecimento grupo = (GrupoEstabelecimento)to;
     *      grupo.setNumeroGrupoEstabelecimento((Long) generatedKeyMap.get(NUMERO_GRUPO_ESTABELECIMENTO));
     *     	</p>
     * </code>
     * 
     * @param generatedKeyMap
     *            Map com os valores das sequences em uso
     * @param to
     *            TO a ser preenchido com os valores das sequences
     */
    protected void mapGeneratedKeys(HashMap generatedKeyMap, Object to) {
    }

    /**
     * <p>
     * Coloca no mapa <code>map</code> os pares chave/valor das sequences
     * encontradas no array <code>mc</code>
     * </p>
     * 
     * @param map
     *            Map com os valores das sequences
     * @param mc
     *            coluna mapeada pela query
     * @param status
     *            conex�o com a base
     */
    private void readSequenceCurrentValues(HashMap map, MappedColumn[] mc, Connection status) {
        for (int i = 0; i < mc.length; i++) {
            if (mc[i].hasSequence()) {
                map.put(mc[i].getName(), sequenceCurrentValue(mc[i].getSequenceName(), status));
            }
        }
    }

    /**
     * <p>
     * Obt�m da base o valor corrente da sequence <code>sequenceName</code>
     * </p>
     * 
     * @param sequenceName
     *            nome da sequence
     * @param status
     *            conex�o com a base
     * 
     * @return valor corrente da sequence
     */
    private Object sequenceCurrentValue(String sequenceName, Connection status) {

        OracleSequenceQuery q = new OracleSequenceQuery();
        return q.executeForObject(new OracleSequence(sequenceName).getCurrentValueSyntax(), ArrayUtils.EMPTY_OBJECT_ARRAY, status);
    }

    /**
     * 
     * @param parameters
     * @param types
     */
    private void mapParameters(Object[] parameters, int[] types) {
        mapParameters(this.ps, parameters, types);
    }

    /**
     * Informa ao <code>PreparedStatement</code> os par�metros a serem
     * utilizados.
     * 
     * @param ps
     *            <code>PreparedStatement</code> que receber� os par�metros
     * @param parameters
     *            Array com os valores dos par�metros
     * @param types
     *            Array com os tipos dos par�metros. Se vazio ou nulo �
     *            desconsiderado
     */
    private void mapParameters(PreparedStatement ps, Object[] parameters, int[] types) {
        try {
            for (int i = 0; i < parameters.length; i++) {
                if (types.length == 0) {
                    ps.setObject(i + 1, parameters[i]);
                } else {
                    ps.setObject(i + 1, parameters[i], types[i]);
                }
            }
        } catch (SQLException e) {
            throw new PersistenceException("Erro ao mapear os par�metros no PreparedStatement", e);
        }
    }

    /**
     * As subclasses precisam implementar esse m�todo para converter cada linha
     * de um <code>ResultSet</code> em um objeto do tipo de resultado
     * pertinente.
     * 
     * @param rs
     *            <code>ResultSet</code> posicionado na linha a ser convertida
     * @return Objeto com os dados convertidos a partir do
     *         <code>ResultSet</code>
     * 
     * @throws SQLException
     */
    protected abstract Object mapRow(ResultSet rs) throws SQLException;

    /**
     * Libera recursos alocados pela inst�ncia.
     * 
     */
    public void release() {
        release(this.ps);
    }

    /**
     * Libera os recursos de banco de dados e recursos JDBC alocados para o
     * <code>PreparedStatement</code>.
     * 
     * OBS: ao liberar o <code>PreparedStatement</code>, automaticamente o
     * <code>ResultSet</code> caso exista tamb�m � liberado.
     * 
     * @param ps
     *            <code>PreparedStatement</code> a ser fechado
     * 
     * @exception SQLException
     *                if a database access error occurs
     */
    protected void release(PreparedStatement ps) {
        if (ps != null) {
            try {
                ps.close();
            } catch (SQLException e) {
                logger.error(e);
            }
        }
    }

    /**
     * Libera os recursos de banco de dados e recursos JDBC alocados para o
     * <code>ResultSet</code>.
     * 
     * @param rs
     *            <code>ResultSet</code> a ser fechado
     */
    protected void release(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                logger.error(e);
            }
        }
    }

    /**
     * <p>
     * Gera uma lista de beans a partir de um <code>ResultSet</code>.
     * </p>
     * <p>
     * Os crit�rios de pagina��o encontrados no par�metro <code>paginacao</code>
     * s�o usados na cria��o do resultado da consulta. Somente as linhas
     * pertencentes � p�gina corrente s�o retornadas.
     * </p>
     * 
     * @param rs
     *            <code>ResultSet</code> com os dados para a gera��o da lista.
     * @param dataPagination
     *            crit�rios de pagina��o (opcional)
     * 
     * @return
     */
    protected List resultSetToList(ResultSet rs, DataPagination dataPagination) {
        List transferObjects = new ArrayList();

        List transferObjectsPagAnterior = new ArrayList();

        createDataList(rs, transferObjects, transferObjectsPagAnterior, dataPagination);

        if (transferObjects.size() == 0) {
            dataPagination.setPage(Math.max(dataPagination.getPage() - 1, 1));
            return transferObjectsPagAnterior;
        } else {
            return transferObjects;
        }
    }

    /**
     * Cria a lista com os dados do ResultSet, de acordo com a configura��o de
     * pagina��o informada.
     * <p>
     * Quando n�o h� pagina��o, � criada uma lista em
     * <code>transferObjects</code> com todas as linhas do ResultSet.
     * </p>
     * <p>
     * Quando h� pagina��o, s�o criadas 2 listas, a da p�gina anterior em
     * <code>transferObjectsPagAnterior</code> e da p�gina corrente em
     * <code>transferObjects</code>.
     * </p>
     * 
     * @param rs
     * @param transferObjects
     * @param transferObjectsPagAnterior
     * @param dataPagination
     */
    private void createDataList(ResultSet rs, List transferObjects, List transferObjectsPagAnterior, DataPagination dataPagination) {
        // ---------------------------------------------------------------------
        // obs: lembrando que o rs tem linhas numeradas a partir de 1, e o array
        // a partir de 0.
        // ---------------------------------------------------------------------
        try {
            while (rs.next()) {
                try {
                    // LISTA DA P�GINA ANTERIOR - se h� pagina��o, copio as
                    // linhas
                    // entre a primeira e �ltima posi��es
                    if (dataPagination.isActive()
                            && (rs.getRow() > dataPagination.currentPageFirstIndex() - dataPagination.getPageSize())
                            && rs.getRow() <= dataPagination.currentPageLastIndex() - dataPagination.getPageSize() + 1)

                        transferObjectsPagAnterior.add(mapRow(rs));

                    // LISTA DA P�GINA CORRENTE OU LISTA COM TODAS AS
                    // OCORRENCIAS -
                    // copio a linha se n�o h� pagina��o,
                    // ou se a linha pertence � p�gina.
                    if (!dataPagination.isActive() || (rs.getRow() > dataPagination.currentPageFirstIndex()))
                        transferObjects.add(mapRow(rs));
                } catch (Throwable e) {
                    throw new PersistenceException("Erro ao executar o mapRow(): " + e.getCause(), e);
                }

                // Se houver pagina��o, as linhas das p�ginas seguintes �
                // corrente
                // n�o s�o copiadas
                if (dataPagination.isActive() && rs.getRow() > dataPagination.currentPageLastIndex()) {
                    break;
                }
            }
        } catch (SQLException e) {
            throw new PersistenceException("Erro ao criar a lista de dados a partir do ResultSet", e);
        }
    }

    /**
     * <p>
     * Atualiza os dados do objeto de transfer�ncia <code>to</code> na base de
     * dados, de acordo com o mapeamento configurado.
     * </p>
     * 
     * @param to
     *            Objeto de transfer�ncia a ser atualizado na base de dados
     * @param con
     */
    public void updateByKey(Object to, Connection con) {
        updateByKey(to, EmptyArray.INT, con);
    }

    /**
     * Executa a query com lista de par�metros. A ordem dos par�metros na lista
     * <code>parms</code> deve ser a mesma em que os mesmos s�o referenciados
     * na query <code>sql</code>.
     * 
     * Os tipos dos par�metros usados na query s�o inferidos a partir dos tipos
     * dos par�metros passados. Caso algum par�metro n�o seja suportado pelo
     * m�todo <code>PreparedStatement.setObject()</code> uma exce��o ser�
     * levantada.
     * 
     * Os dados s�o retornados numa lista. Cada item da lista � populado pelo
     * m�todo <code>mapRow</code>.
     * 
     * @param sql
     *            Query a ser executada
     * @param parametros
     *            Parametros passados para a query, na ordem em que s�o
     *            referenciados
     * @param con
     *            Conex�o com o banco
     * @param dataPagination
     *            Crit�rios de pagina��o de dados
     * 
     * @return Lista com os dados obtidos na execu��o da query
     */
    public List executeQuery(String sql, Object[] parametros, Connection connection, DataPagination dataPagination) {

        if (logger.isDebugEnabled()) {
            logger.debug(this.getClass().getName().concat(": M�todo executeQuery() - SQL: [").concat(sql)
                    .concat("] --Parametros: ").concat(objectArrayToString(parametros)));
        }

        ResultSet rs = null;
        PreparedStatement statement = null;

        try {
            statement = connection.prepareStatement(sql);

            mapParameters(statement, parametros, EmptyArray.INT);

            rs = statement.executeQuery();
            List objects = resultSetToList(rs, dataPagination);

            return objects;
        } catch (SQLException e) {
            throw new PersistenceException(ERRO_QUERY_INTRO, e);
        } finally {
            release(rs);
            release(statement);
        }
    }

    /**
     * Verifica a exist�ncia de um objeto na persist�ncia mapeada pela query.
     * 
     * @param to
     *            Objeto a ser localizado
     * @param connection
     *            Conex�o com a base
     * 
     * @return <code>true</code> caso o objeto exista, <code>false</code>
     *         caso contr�rio
     */
    public boolean exists(Object to, Connection connection) {
        return executeCount(getFindByKey(), getPKParameters(to), connection) == 1;
    }

    /**
     * Obt�m o total de registros de uma query informada.
     * 
     * @param query
     *            query da qual se quer calcular o total de registros
     * @param parametros
     *            par�metros de execu��o da query
     * @param connection
     *            conex�o com a base de dados
     */
    public int executeCount(String query, Object[] parametros, Connection connection) {

        String countQuery = "SELECT COUNT(*) from (" + query + ")";
        PreparedStatement statement = null;
        ResultSet rs = null;

        if (logger.isDebugEnabled()) {
            logger.debug(this.getClass().getName().concat(": M�todo executeCount() - SQL: [").concat(countQuery).concat(
                    "] --Parametros: ").concat(objectArrayToString(parametros)));
        }

        try {
            statement = connection.prepareStatement(countQuery);
            mapParameters(statement, parametros, EmptyArray.INT);
            rs = statement.executeQuery();
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            throw new PersistenceException(ERRO_QUERY_INTRO, e);
        } finally {
            release(rs);
            release(statement);
        }
    }
}