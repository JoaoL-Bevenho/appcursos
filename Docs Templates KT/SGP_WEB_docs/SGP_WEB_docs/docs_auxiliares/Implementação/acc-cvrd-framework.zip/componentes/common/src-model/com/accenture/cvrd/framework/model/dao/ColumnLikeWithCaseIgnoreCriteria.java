package com.accenture.cvrd.framework.model.dao;

/**
 * Crit�rio de compara��o por semelhan�a para ser aplicado em uma coluna. A
 * coluna satisfaz o crit�rio quando o seu conte�do contiver o valor do
 * crit�rio, considerando os wilcards usados no valor.
 * 
 * O valor � convertido para caixa alta, usando o <code>Locale</code> default.
 * 
 * @author ricardo.goes
 * 
 */
public class ColumnLikeWithCaseIgnoreCriteria extends ColumnLikeCriteria {

	/**
	 * Construtor
	 * 
	 * @param column
	 *            nome da coluna onde o crit�rio � aplicado
	 * @param value
	 *            Valor a ser procurado na coluna
	 */
	public ColumnLikeWithCaseIgnoreCriteria(String column, String value) {
		super(column, value != null ? value.toUpperCase() : null);
	}

	/**
	 * @see ColumnCriteria#render(CriteriaRenderer)
	 */
	public String render(CriteriaRenderer criteriaRenderer) {
		return criteriaRenderer.renderCriteria(this);
	}
}
