package com.accenture.cvrd.framework.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Query especializada em manipula��o de objetos <code>sequence</code> do
 * <i>Oracle</i>.
 * 
 * @author ricardo.goes
 * 
 */
public class OracleSequenceQuery extends MappingQuery {

	/**
	 * m�todo sem utiliza��o nessa classe
	 */
	protected MappedColumn[] getNonPkColumns() {
		return null;
	}

	/**
	 * m�todo sem utiliza��o nessa classe
	 */
	protected Object[] getNonPKParameters(Object transferObject) {
		return null;
	}

	/**
	 * m�todo sem utiliza��o nessa classe
	 */
	protected MappedColumn[] getPkColumns() {
		return null;
	}

	/**
	 * m�todo sem utiliza��o nessa classe
	 */
	protected Object[] getPKParameters(Object transferObject) {
		return null;
	}

	/**
	 * m�todo sem utiliza��o nessa classe
	 */
	protected String getTable() {
		return null;
	}

	protected Object mapRow(ResultSet rs) throws SQLException {
		return new Long(rs.getLong(1));
	}

	/**
	 * @see MappingQuery#initColumns()
	 */
	protected void initColumns() {
	}

	/**
	 * m�todo sem utiliza��o nessa classe
	 */
	public boolean exists(Object to, Connection status) {
		return false;
	}
}
