package com.accenture.cvrd.framework.model.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.cvrd.framework.db.pool.ConnectionPool;
import br.com.cvrd.framework.exception.PersistenceException;

/**
 * Template para uso de conex�o com o banco. Encapsula a obten��o e libera��o da
 * conex�o.
 * 
 * Permite retornar na execu��o do template qualquer objeto.
 * 
 * @author ricardo.goes
 * 
 */
public abstract class ConnectionTemplate {

    Log logger = LogFactory.getLog(ConnectionTemplate.class);

    /**
     * M�todo abstrato a ser implementado pelas classes que extendem esse
     * template. � executado no escopo de uma conex�o aberta.
     * 
     * @param conexao
     *            Conex�o dispon�vel com o banco de dados.
     * 
     * @return Qualquer objeto que se queira ter como retorno da execu��o do
     *         template.
     */
    public abstract Object doInConnection(final Connection conexao);

    /**
     * M�todo que implementa o template. � o m�todo a ser chamado, que controla
     * a execu��o do m�todo abstrato <code>doInConnection()</code>.
     * 
     * Retorna qualquer objeto que se queira ter como retorno da execu��o do
     * template.
     * 
     * @return
     */
    public Object execute() {
        ConnectionPool connectionPool = ConnectionPoolHelper.getConnectionPool();

        Connection conexao = null;

        try {
            conexao = connectionPool.getConnection();
            conexao.setAutoCommit(false);

            return doInConnection(conexao);
        } catch (SQLException e) {
            throw new PersistenceException(e);
        } finally {
            if (conexao != null) {
                try {
                    connectionPool.freeConnection(conexao);
                } catch (SQLException e) {
                    throw new PersistenceException(e);
                }
            }
        }
    }
}
