package com.accenture.cvrd.framework.model.dao;

/**
 * Classes que representam operadores booleanos usados em crit�rios de query
 * devem implementar essa interface
 * 
 * @author ricardo.goes
 * @see QueryCriteria
 */
public interface BooleanOperator {

}
