package com.accenture.cvrd.framework.model.dao;

import java.sql.Connection;

/**
 * Template para uso de conex�o com o banco. Encapsula a obten��o e libera��o da
 * conex�o.
 * 
 * @author ricardo.goes
 * @see ConnectionTemplate
 */
public abstract class ConnectionTemplateWithoutResult extends ConnectionTemplate {

	/**
	 * M�todo implementado para desviar a execu��o para o m�todo abstrato
	 * <code>doInConnectionWithoutResult()</code>.
	 * 
	 * @param conexao
	 *            Conex�o dispon�vel com o banco de dados.
	 * 
	 * @return <code>null</code>.
	 */
	public Object doInConnection(Connection conexao) {
		doInConnectionWithoutResult(conexao);
		return null;
	}

	/**
	 * M�todo abstrato a ser implementado pelas classes que extendem esse
	 * template. � executado no escopo de uma conex�o aberta.
	 * 
	 * @param conexao
	 *            Conex�o dispon�vel com o banco de dados.
	 * 
	 */
	public abstract void doInConnectionWithoutResult(Connection conexao);
}
