package com.accenture.cvrd.framework.model.dao;

import com.accenture.cvrd.framework.util.StringHelper;

/**
 * Classe abstrata para representar um crit�rio de query baseado em coluna de
 * uma fonte de dados. Um crit�rio pode ser aplicado a uma query para filtrar dados
 * afetados por ela.
 * 
 * @author ricardo.goes
 * @see QueryCriteria
 * 
 */
public abstract class ColumnCriteria extends QueryCriteria {

	private String column;

	/**
	 * Construtor
	 * 
	 * @param column
	 *            nome da coluna onde o crit�rio � aplicado
	 * @param operadorBooleano
	 *            operador booleano usado para conectar o crit�rio ao crit�rio
	 *            anterior caso exista.
	 */
	public ColumnCriteria(String column, BooleanOperator operadorBooleano) {
		super();
		this.column = column;
		this.setOperadorBooleano(operadorBooleano);
	}

	/**
	 * Construtor
	 * 
	 * @param column
	 *            nome da coluna onde o crit�rio � aplicado
	 */
	public ColumnCriteria(String column) {
		super();
		this.column = column;
	}

	/**
	 * getter do nome da coluna onde o crit�rio � aplicado
	 * 
	 * @return nome da coluna onde o crit�rio � aplicado
	 */
	public String getColumn() {
		return this.column;
	}

	/**
	 * M�todo abstrato que dever� retornar um array com os valores do crit�rio
	 * que s�o aplic�veis na renderiza��o.
	 * 
	 * @return array com os valores do crit�rio que s�o aplic�veis na
	 *         renderiza��o
	 */
	public abstract Object[] getApplicableValues();

	/**
	 * Retorna <code>true</code> caso o crit�rio seja aplic�vel.
	 */
	public boolean isApplicable() {
		return getApplicableValues().length > 0;
	}

	/**
	 * Retorna <code>true</code> caso o valor <code>aValue</code> seja nulo
	 * ou vazio. Valores nulos ser�o considerados n�o aplic�veis no uso do
	 * crit�rio.
	 * 
	 * @param aValue
	 *            valor a ser testado
	 * @return
	 */
	protected boolean isNull(Object aValue) {
		return aValue == null || (aValue instanceof String && StringHelper.isEmpty((String) aValue));
	}

	/**
     * Retorna <code>true</code> caso o valor <code>aValue</code> seja nulo
     * vazio, ou s� possua brancos. Valores 'vazios' ser�o considerados n�o 
     * aplic�veis no uso do crit�rio.
     * 
     * @param aValue
     *            valor a ser testado
     * @return
     */
    protected boolean isEmpty(Object aValue) {
        return aValue == null || (aValue instanceof String && StringHelper.isEmpty(((String) aValue).trim()));
    }
}
