package com.accenture.cvrd.framework.model.dao;

/**
 * Objeto <i>sequence</i> do Oracle.
 * 
 * @author ricardo.goes
 * 
 */
public class OracleSequence {

	private String sequenceName;

	/**
	 * Constr�i a query para a <i>sequence</i> informada.
	 * 
	 * @param sequenceName
	 */
	public OracleSequence(String sequenceName) {
		this.sequenceName = sequenceName;
	}

	/**
	 * Retorna a a sintaxe para a obten��o do pr�ximo valor de uma coluna do
	 * tipo <code>sequence</code>.
	 * 
	 * @return sintaxe para a obten��o do pr�ximo valor de uma coluna do tipo
	 *         <code>sequence</code>
	 */
	public String getNextValueSyntax() {
		return "select " + sequenceName + ".nextval from dual";
	}

	/**
	 * Retorna a a sintaxe para a obten��o do valor corrente de uma coluna do
	 * tipo <code>sequence</code>.
	 * 
	 * @return sintaxe para a obten��o do valor corrente de uma coluna do tipo
	 *         <code>sequence</code>
	 */
	public String getCurrentValueSyntax() {
		return "select " + sequenceName + ".currval from dual";
	}
}