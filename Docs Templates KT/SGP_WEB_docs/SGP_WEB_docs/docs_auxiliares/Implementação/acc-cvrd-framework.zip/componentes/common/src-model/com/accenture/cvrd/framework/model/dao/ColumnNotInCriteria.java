package com.accenture.cvrd.framework.model.dao;

import java.util.Iterator;

/**
 * Crit�rio de compara��o com op��es para ser aplicado em uma coluna.
 * O crit�rio � satisfeito quando o atributo n�o for igual a nenhuma das op��es.
 * 
 * @author ricardo.goes
 * 
 */
public class ColumnNotInCriteria extends ColumnInCriteria {

    /**
     * Construtor
     * 
     * @param attribute
     *            nome da coluna onde o crit�rio � aplicado
     * @param values
     *            Valores (op��es) a serem comparados com a coluna
     */
    public ColumnNotInCriteria(String attribute, Iterator values) {
        super(attribute, values);
    }

    /**
     * Construtor
     * 
     * @param attribute
     *            nome da coluna onde o crit�rio � aplicado
     * @param values
     *            Valores (op��es) a serem comparados com a coluna
     */
    public ColumnNotInCriteria(String attribute, Object[] values) {
        super(attribute, values);
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.ColumnInCriteria#render(com.accenture.cvrd.framework.model.dao.CriteriaRenderer)
     */
    public String render(CriteriaRenderer criteriaRenderer) {
        return criteriaRenderer.renderCriteria(this);
    }
}
