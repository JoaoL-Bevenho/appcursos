package com.accenture.cvrd.framework.model.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.accenture.cvrd.framework.util.EmptyArray;

/**
 * Crit�rio de compara��o com op��es para ser aplicado em uma coluna.
 * O crit�rio � satisfeito quando o atributo for igual a qualquer das op��es.
 * 
 * @author ricardo.goes
 * 
 */
public class ColumnInCriteria extends ColumnCriteria {

    Object[] values = EmptyArray.OBJECT;

    /**
     * Construtor
     * 
     * @param attribute
     *            nome da coluna onde o crit�rio � aplicado
     * @param values
     *            Valores (op��es) a serem comparados com a coluna
     */
    public ColumnInCriteria(String attribute, Iterator values) {
        super(attribute);
        this.values = removeNulos(values);
    }

    private Object[] removeNulos(Iterator values) {
        List l = new ArrayList();

        while (values.hasNext()) {
            Object o = values.next();
            if (o != null) {
                l.add(o);
            }
        }

        return l.toArray();
    }

    /**
     * Construtor
     * 
     * @param attribute
     *            nome da coluna onde o crit�rio � aplicado
     * @param values
     *            Valores (op��es) a serem comparados com a coluna
     */
    public ColumnInCriteria(String attribute, Object[] values) {
        super(attribute);
        this.values = removeNulos(values);
    }

    /**
     * Retorna um array com os valores n�o nulos encontrados no array fornecido.
     *  
     * @param values
     * @return
     */
    private Object[] removeNulos(Object[] values) {
        ArrayList l = new ArrayList();

        for (int i = 0; i < values.length; i++) {
            Object o = values[i];
            if (o != null) {
                l.add(o);
            }
        }

        return l.toArray();
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.ColumnCriteria#getApplicableValues()
     */
    public Object[] getApplicableValues() {
        return values;
    }

    /*
     * (non-Javadoc)
     * @see com.accenture.cvrd.framework.model.dao.QueryCriteria#render(com.accenture.cvrd.framework.model.dao.CriteriaRenderer)
     */
    public String render(CriteriaRenderer criteriaRenderer) {
        return criteriaRenderer.renderCriteria(this);
    }
}
