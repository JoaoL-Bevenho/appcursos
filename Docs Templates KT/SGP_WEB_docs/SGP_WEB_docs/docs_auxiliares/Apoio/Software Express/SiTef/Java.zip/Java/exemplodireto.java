import softwareexpress.sitef.*;
import java.io.*;

class exemplodireto
{ 

  public static void main (String[] args) 
  {
    int S;
    jCliSiTefI CliSiTef = new jCliSiTefI ( );
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    int ProximoComando;
    byte [ ] DadosTx;
    byte [ ] DadosRx;
    short CodigoResposta;
    String CupomFiscal = "1122334455";
    String Mensagem;

    if (args.length != 1)
    {
      System.out.println ("Forma de uso: java exemplodireto IP-SiTef");
      System.exit (1);
    }
      
    CliSiTef.SetEnderecoSiTef (args[0]);
    CliSiTef.SetCodigoLoja ("00000000");
    CliSiTef.SetNumeroTerminal ("SE000001");
    CliSiTef.SetConfiguraResultado (0);
    S = CliSiTef.ConfiguraIntSiTefInterativo ( );
    if (S != 0)
    {
      System.out.println ("Erro na ConfiguraIntSiTefInterativo (" + args[0] + ")= " + S);
      System.exit (1);
    }

    CliSiTef.SetRedeDestino (33);
    CliSiTef.SetFuncaoSiTef (240);
    CliSiTef.SetOffsetCartao (0);
    Mensagem = ("2\0" + "123456789012\0" + CupomFiscal + "\0" + "2\0" + "0001\0" + "3\0" + "0002\0" + "5\0");
    DadosTx = Mensagem.getBytes ( );
    CliSiTef.SetDadosTx (DadosTx);
    CliSiTef.SetTamDadosTx (DadosTx.length);
    CliSiTef.SetTamMaxDadosRx (1024);
    CliSiTef.SetTempoEsperaRx (30);
    CliSiTef.SetNumeroCuponFiscal (CupomFiscal);
    CliSiTef.SetDataFiscal ("20040514");
    CliSiTef.SetHorario ("120000");
    CliSiTef.SetOperador ("Operador1");
    CliSiTef.SetTipoTransacao (1);
    S = CliSiTef.EnviaRecebeSiTefDireto ( );
    DadosRx = CliSiTef.GetDadosRx ( );
    if (S > 0)
    {
      System.out.println ("Tam Dados Rx= " + S);
      System.out.println ("Tam primeiro servico= " + DadosRx[0]);
    }
  
    CodigoResposta = CliSiTef.GetCodigoResposta ( );
    System.out.println ("EnviaRecebeSiTefDireto retornou " + CodigoResposta);
  } 
} 

