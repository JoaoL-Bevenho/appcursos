import softwareexpress.sitef.*;
import java.io.*;

class exemplo
{
  public static void main (String[] args)
  {
    int S;
    jCliSiTefI CliSiTef = new jCliSiTefI ( );
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    int ProximoComando;

    if (args.length != 1)
    {
      System.out.println ("Forma de uso: java exemplo IP-SiTef");
      System.exit (1);
    }

    CliSiTef.SetEnderecoSiTef (args[0]);
    CliSiTef.SetCodigoLoja ("00000000");
    CliSiTef.SetNumeroTerminal ("SE000001");
    CliSiTef.SetConfiguraResultado (0);
    S = CliSiTef.ConfiguraIntSiTefInterativo ( );
    if (S != 0)
    {
      System.out.println ("Erro na ConfiguraIntSiTefInterativo (" + args[0] + ")= " + S);
      System.exit (1);
    }

    CliSiTef.SetModalidade (0);
    CliSiTef.SetValor ("5000");
    CliSiTef.SetNumeroCuponFiscal ("123456");
    CliSiTef.SetDataFiscal ("20040514");
    CliSiTef.SetHorario ("120000");
    CliSiTef.SetOperador ("Operador1");
    CliSiTef.SetRestricoes ("xxxxxx");
    S = CliSiTef.IniciaFuncaoSiTefInterativo ( );
    CliSiTef.SetBuffer ("");
    CliSiTef.SetContinuaNavegacao (0);
    while (true)
    {
      S = CliSiTef.ContinuaFuncaoSiTefInterativo ( );
      if (S != 10000)
        break;

      //  Aqui deve-se colocar o tratamento de cada tipo de ProximoComando
      System.out.println ("ProximoComando = " + CliSiTef.GetProximoComando ( ));
      System.out.println ("TipoCampo = " + CliSiTef.GetTipoCampo ( ));
      System.out.println ("TamanhoMinimo = " + CliSiTef.GetTamanhoMinimo ( ));
      System.out.println ("TamanhoMaximo = " + CliSiTef.GetTamanhoMaximo ( ));
      System.out.println ("Buffer = " + CliSiTef.GetBuffer ( ));

      ProximoComando = CliSiTef.GetProximoComando ( );
      if (ProximoComando >= 20 &&
          ProximoComando != 23 && ProximoComando != 22)
      {
        try {
          CliSiTef.SetBuffer (in.readLine ( ));
        } catch (IOException e) {
        }
      }
    }

    if (S != 10000)
    {
      System.out.println ("ContinuaFuncaoSiTefInterativo retornou " + S);
      System.out.println ("Trn pendentes: " + CliSiTef.ObtemQuantidadeTransacoesPendentes ());
      CliSiTef.SetConfirma ((short)1);
      CliSiTef.FinalizaTransacaoSiTefInterativo ();
    }
  }
}

